# The aeon2yw_novelyst plugin

## How to install

- Unzip the downloaded zipfile into a new folder.
- Move into this new folder and launch **setup.pyw**. This installs the plugin.
- The plugin's features are accessible via the **Tools > Aeon timeline 2** menu in *novelyst*.



## See also:

Home page of the novelyst application: https://peter88213.github.io/novelyst
Home page of the aeon2yw application: https://peter88213.github.io/aeon2yw
