"""Aeon Timeline 2 sync plugin for novelyst.

Version 3.4.1
Requires Python 3.6+
Copyright (c) 2023 Peter Triesberger
For further information see https://github.com/peter88213/novelyst_aeon2
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import os
import sys
from pathlib import Path
import tkinter as tk
import locale
import gettext
import webbrowser
from tkinter import messagebox
from datetime import datetime

__all__ = ['Error',
           '_',
           'LOCALE_PATH',
           'CURRENT_LANGUAGE',
           'norm_path',
           'string_to_list',
           'list_to_string',
           ]


class Error(Exception):
    pass


LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('pywriter', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''

import re
from typing import Iterator, Pattern


class BasicElement:

    def __init__(self):
        self.title: str = None

        self.desc: str = None

        self.kwVar: dict[str, str] = {}


class Chapter(BasicElement):

    def __init__(self):
        super().__init__()

        self.chLevel: int = None

        self.chType: int = None

        self.suppressChapterTitle: bool = None

        self.isTrash: bool = None

        self.suppressChapterBreak: bool = None

        self.srtScenes: list[str] = []
from typing import Pattern


ADDITIONAL_WORD_LIMITS: Pattern = re.compile('--|—|–')

NO_WORD_LIMITS: Pattern = re.compile('\[.+?\]|\/\*.+?\*\/|-|^\>', re.MULTILINE)

NON_LETTERS: Pattern = re.compile('\[.+?\]|\/\*.+?\*\/|\n|\r')


class Scene(BasicElement):
    STATUS: set = (None, 'Outline', 'Draft', '1st Edit', '2nd Edit', 'Done')

    ACTION_MARKER: str = 'A'
    REACTION_MARKER: str = 'R'
    NULL_DATE: str = '0001-01-01'
    NULL_TIME: str = '00:00:00'

    def __init__(self):
        super().__init__()

        self._sceneContent: str = None

        self.wordCount: int = 0

        self.letterCount: int = 0

        self.scType: int = None

        self.doNotExport: bool = None

        self.status: int = None

        self.notes: str = None

        self.tags: list[str] = None

        self.field1: str = None

        self.field2: str = None

        self.field3: str = None

        self.field4: str = None

        self.appendToPrev: bool = None

        self.isReactionScene: bool = None

        self.isSubPlot: bool = None

        self.goal: str = None

        self.conflict: str = None

        self.outcome: str = None

        self.characters: list[str] = None

        self.locations: list[str] = None

        self.items: list[str] = None

        self.date: str = None

        self.time: str = None

        self.day: str = None

        self.lastsMinutes: str = None

        self.lastsHours: str = None

        self.lastsDays: str = None

        self.image: str = None

        self.scnArcs: str = None

        self.scnStyle: str = None

    @property
    def sceneContent(self) -> str:
        return self._sceneContent

    @sceneContent.setter
    def sceneContent(self, text: str):
        self._sceneContent = text
        text = ADDITIONAL_WORD_LIMITS.sub(' ', text)
        text = NO_WORD_LIMITS.sub('', text)
        wordList = text.split()
        self.wordCount = len(wordList)
        text = NON_LETTERS.sub('', self._sceneContent)
        self.letterCount = len(text)


class WorldElement(BasicElement):

    def __init__(self):
        super().__init__()

        self.image: str = None

        self.tags: list[str] = None

        self.aka: str = None



class Character(WorldElement):
    MAJOR_MARKER: str = 'Major'
    MINOR_MARKER: str = 'Minor'

    def __init__(self):
        super().__init__()

        self.notes: str = None

        self.bio: str = None

        self.goals: str = None

        self.fullName: str = None

        self.isMajor: bool = None

LANGUAGE_TAG: Pattern = re.compile('\[lang=(.*?)\]')


class Novel(BasicElement):

    def __init__(self):
        super().__init__()

        self.authorName: str = None

        self.authorBio: str = None

        self.fieldTitle1: str = None

        self.fieldTitle2: str = None

        self.fieldTitle3: str = None

        self.fieldTitle4: str = None

        self.wordTarget: int = None

        self.wordCountStart: int = None

        self.wordTarget: int = None

        self.chapters: dict[str, Chapter] = {}

        self.scenes: dict[str, Scene] = {}

        self.languages: list[str] = None

        self.srtChapters: list[str] = []

        self.locations: dict[str, WorldElement] = {}

        self.srtLocations: list[str] = []

        self.items: dict[str, WorldElement] = {}

        self.srtItems: list[str] = []

        self.characters: dict[str, Character] = {}

        self.srtCharacters: list[str] = []

        self.projectNotes: dict[str, BasicElement] = {}

        self.srtPrjNotes: list[str] = []

        self.languageCode: str = None

        self.countryCode: str = None

    def get_languages(self):

        def languages(text: str) -> Iterator[str]:
            if text:
                m = LANGUAGE_TAG.search(text)
                while m:
                    text = text[m.span()[1]:]
                    yield m.group(1)
                    m = LANGUAGE_TAG.search(text)

        self.languages = []
        for scId in self.scenes:
            text = self.scenes[scId].sceneContent
            if text:
                for language in languages(text):
                    if not language in self.languages:
                        self.languages.append(language)

    def check_locale(self):
        if not self.languageCode:
            try:
                sysLng, sysCtr = locale.getlocale()[0].split('_')
            except:
                sysLng, sysCtr = locale.getdefaultlocale()[0].split('_')
            self.languageCode = sysLng
            self.countryCode = sysCtr
            return

        try:
            if len(self.languageCode) == 2:
                if len(self.countryCode) == 2:
                    return
        except:
            pass
        self.languageCode = 'zxx'
        self.countryCode = 'none'

from configparser import ConfigParser


class Configuration:

    def __init__(self, settings={}, options={}):
        self.settings = None
        self.options = None
        self._sLabel = 'SETTINGS'
        self._oLabel = 'OPTIONS'
        self.set(settings, options)

    def read(self, iniFile):
        config = ConfigParser()
        config.read(iniFile, encoding='utf-8')
        if config.has_section(self._sLabel):
            section = config[self._sLabel]
            for setting in self.settings:
                fallback = self.settings[setting]
                self.settings[setting] = section.get(setting, fallback)
        if config.has_section(self._oLabel):
            section = config[self._oLabel]
            for option in self.options:
                fallback = self.options[option]
                self.options[option] = section.getboolean(option, fallback)

    def set(self, settings=None, options=None):
        if settings is not None:
            self.settings = settings.copy()
        if options is not None:
            self.options = options.copy()

    def write(self, iniFile):
        config = ConfigParser()
        if self.settings:
            config.add_section(self._sLabel)
            for settingId in self.settings:
                config.set(self._sLabel, settingId, str(self.settings[settingId]))
        if self.options:
            config.add_section(self._oLabel)
            for settingId in self.options:
                if self.options[settingId]:
                    config.set(self._oLabel, settingId, 'Yes')
                else:
                    config.set(self._oLabel, settingId, 'No')
        with open(iniFile, 'w', encoding='utf-8') as f:
            config.write(f)


def open_document(document):
    try:
        os.startfile(norm_path(document))
    except:
        try:
            os.system('xdg-open "%s"' % norm_path(document))
        except:
            try:
                os.system('open "%s"' % norm_path(document))
            except:
                pass
from datetime import datetime
from datetime import timedelta
from typing import Iterable


def create_id(elements: Iterable) -> str:
    i = 1
    while str(i) in elements:
        i += 1
    return str(i)

from urllib.parse import quote


class File:
    DESCRIPTION = _('File')
    EXTENSION = None
    SUFFIX = None

    PRJ_KWVAR = []
    CHP_KWVAR = []
    SCN_KWVAR = []
    CRT_KWVAR = []
    LOC_KWVAR = []
    ITM_KWVAR = []
    PNT_KWVAR = []

    def __init__(self, filePath, **kwargs):
        super().__init__()
        self.novel = None

        self._filePath = None

        self.projectName = None

        self.projectPath = None

        self.scenesSplit = False
        self.filePath = filePath

    @property
    def filePath(self):
        return self._filePath

    @filePath.setter
    def filePath(self, filePath):
        if self.SUFFIX is not None:
            suffix = self.SUFFIX
        else:
            suffix = ''
        if filePath.lower().endswith(f'{suffix}{self.EXTENSION}'.lower()):
            self._filePath = filePath
            try:
                head, tail = os.path.split(os.path.realpath(filePath))
            except:
                head, tail = os.path.split(filePath)
            self.projectPath = quote(head.replace('\\', '/'), '/:')
            self.projectName = quote(tail.replace(f'{suffix}{self.EXTENSION}', ''))

    def read(self):
        raise NotImplementedError

    def write(self):
        raise NotImplementedError

    def _convert_from_yw(self, text, quick=False):
        return text.rstrip()

    def _convert_to_yw(self, text):
        return text.rstrip()

import zipfile
import codecs
import json
from json import JSONDecodeError


def open_timeline(filePath):
    try:
        with zipfile.ZipFile(filePath, 'r') as myzip:
            jsonBytes = myzip.read('timeline.json')
            jsonStr = codecs.decode(jsonBytes, encoding='utf-8')
    except:
        raise Error(f'{_("Cannot read timeline data")}.')
    if not jsonStr:
        raise Error(f'{_("No JSON part found in timeline data")}.')
    try:
        jsonData = json.loads(jsonStr)
    except JSONDecodeError:
        raise Error(f'{_("Invalid JSON data in timeline")}.')
    return jsonData


def save_timeline(jsonData, filePath):
    backedUp = False
    if os.path.isfile(filePath):
        try:
            os.replace(filePath, f'{filePath}.bak')
        except:
            raise Error(f'{_("Cannot overwrite file")}: "{norm_path(filePath)}".')
        else:
            backedUp = True
    try:
        with zipfile.ZipFile(filePath, 'w', compression=zipfile.ZIP_DEFLATED) as f:
            f.writestr('timeline.json', json.dumps(jsonData))
    except:
        if backedUp:
            os.replace(f'{filePath}.bak', filePath)
        raise Error(f'{_("Cannot write file")}: "{norm_path(filePath)}".')

from hashlib import pbkdf2_hmac

guidChars = list('ABCDEF0123456789')


def get_sub_guid(key, size):
    keyInt = int.from_bytes(key, byteorder='big')
    guid = ''
    while len(guid) < size and keyInt > 0:
        guid += guidChars[keyInt % len(guidChars)]
        keyInt //= len(guidChars)
    return guid


def get_uid(text):
    text = text.encode('utf-8')
    sizes = [8, 4, 4, 4, 12]
    salts = [b'a', b'b', b'c', b'd', b'e']
    guid = []
    for i in range(5):
        key = pbkdf2_hmac('sha1', text, salts[i], 1)
        guid.append(get_sub_guid(key, sizes[i]))
    return '-'.join(guid)
import math


def get_moon_phase(dateStr):
    try:
        y, m, d = dateStr.split('-')
        year = int(y)
        month = int(m)
        day = int(d)
        r = year % 100
        r %= 19
        if r > 9:
            r -= 19
        r = ((r * 11) % 30) + month + day
        if month < 3:
            r += 2
        if year < 2000:
            r -= 4
        else:
            r -= 8.3
        r = math.floor(r + 0.5) % 30
        if r < 0:
            r += 30
    except:
        r = None
    return r


def get_moon_phase_plus(dateStr):
    s = '  ))))))))))))OOO(((((((((((( '
    p = '00¼¼¼¼½½½½¾¾¾¾111¾¾¾¾½½½½¼¼¼¼0'
    r = get_moon_phase(dateStr)
    if r is not None:
        result = f'{r} [  {s[r]}  ] {p[r]}'
    else:
        result = ''
    return result




class JsonTimeline2(File):
    EXTENSION = '.aeonzip'
    DESCRIPTION = _('Aeon Timeline 2 project')
    SUFFIX = ''
    VALUE_YES = '1'
    DATE_LIMIT = (datetime(100, 1, 1) - datetime.min).total_seconds()
    PROPERTY_MOONPHASE = 'Moon phase'

    SCN_KWVAR = [
        'Field_SceneArcs',
        ]
    CRT_KWVAR = [
        'Field_BirthDate',
        'Field_DeathDate',
        ]

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath, **kwargs)
        self._jsonData = None

        self._entityNarrative = kwargs['narrative_arc']

        self._propertyDesc = kwargs['property_description']
        self._propertyNotes = kwargs['property_notes']

        self._roleLocation = kwargs['role_location']
        self._roleItem = kwargs['role_item']
        self._roleCharacter = kwargs['role_character']

        self._typeCharacter = kwargs['type_character']
        self._typeLocation = kwargs['type_location']
        self._typeItem = kwargs['type_item']

        self._tplDateGuid = None
        self._typeArcGuid = None
        self._typeCharacterGuid = None
        self._typeLocationGuid = None
        self._typeItemGuid = None
        self._roleArcGuid = None
        self._roleStorylineGuid = None
        self._roleCharacterGuid = None
        self._roleLocationGuid = None
        self._roleItemGuid = None
        self._entityNarrativeGuid = None
        self._propertyDescGuid = None
        self._propertyNotesGuid = None
        self._propertyMoonphaseGuid = None

        self.referenceDateStr = kwargs['default_date_time']
        try:
            self.referenceDate = datetime.fromisoformat(self.referenceDateStr)
        except ValueError:
            self.referenceDate = datetime.today()
        self._scenesOnly = kwargs['scenes_only']
        self._addMoonphase = kwargs['add_moonphase']
        self._sceneColor = kwargs['color_scene']
        self._eventColor = kwargs['color_event']
        self._pointColor = kwargs['color_point']
        self._timestampMax = 0
        self._displayIdMax = 0.0
        self._colors = {}
        self._arcCount = 0
        self._characterGuidById = {}
        self._locationGuidById = {}
        self._itemGuidById = {}
        self._trashEvents = []
        self._arcGuidsByName = {}

    def read(self):
        self._jsonData = open_timeline(self.filePath)

        for tplCol in self._jsonData['template']['colors']:
            self._colors[tplCol['name']] = tplCol['guid']

        for tplRgp in self._jsonData['template']['rangeProperties']:
            if tplRgp['type'] == 'date':
                for tplRgpCalEra in tplRgp['calendar']['eras']:
                    if tplRgpCalEra['name'] == 'AD':
                        self._tplDateGuid = tplRgp['guid']
                        break

        if self._tplDateGuid is None:
            raise Error(_('"AD" era is missing in the calendar.'))

        for tplTyp in self._jsonData['template']['types']:
            if tplTyp['name'] == 'Arc':
                self._typeArcGuid = tplTyp['guid']
                for tplTypRol in tplTyp['roles']:
                    if tplTypRol['name'] == 'Arc':
                        self._roleArcGuid = tplTypRol['guid']
                    elif tplTypRol['name'] == 'Storyline':
                        self._roleStorylineGuid = tplTypRol['guid']
            elif tplTyp['name'] == self._typeCharacter:
                self._typeCharacterGuid = tplTyp['guid']
                for tplTypRol in tplTyp['roles']:
                    if tplTypRol['name'] == self._roleCharacter:
                        self._roleCharacterGuid = tplTypRol['guid']
            elif tplTyp['name'] == self._typeLocation:
                self._typeLocationGuid = tplTyp['guid']
                for tplTypRol in tplTyp['roles']:
                    if tplTypRol['name'] == self._roleLocation:
                        self._roleLocationGuid = tplTypRol['guid']
                        break

            elif tplTyp['name'] == self._typeItem:
                self._typeItemGuid = tplTyp['guid']
                for tplTypRol in tplTyp['roles']:
                    if tplTypRol['name'] == self._roleItem:
                        self._roleItemGuid = tplTypRol['guid']
                        break

        if self._typeArcGuid is None:
            self._typeArcGuid = get_uid('typeArcGuid')
            typeCount = len(self._jsonData['template']['types'])
            self._jsonData['template']['types'].append(
                {
                    'color': 'iconYellow',
                    'guid': self._typeArcGuid,
                    'icon': 'book',
                    'name': 'Arc',
                    'persistent': True,
                    'roles': [],
                    'sortOrder': typeCount
                })
        for entityType in self._jsonData['template']['types']:
            if entityType['name'] == 'Arc':
                if self._roleArcGuid is None:
                    self._roleArcGuid = get_uid('_roleArcGuid')
                    entityType['roles'].append(
                        {
                        'allowsMultipleForEntity': True,
                        'allowsMultipleForEvent': True,
                        'allowsPercentAllocated': False,
                        'guid': self._roleArcGuid,
                        'icon': 'circle text',
                        'mandatoryForEntity': False,
                        'mandatoryForEvent': False,
                        'name': 'Arc',
                        'sortOrder': 0
                        })
                if self._roleStorylineGuid is None:
                    self._roleStorylineGuid = get_uid('_roleStorylineGuid')
                    entityType['roles'].append(
                        {
                        'allowsMultipleForEntity': True,
                        'allowsMultipleForEvent': True,
                        'allowsPercentAllocated': False,
                        'guid': self._roleStorylineGuid,
                        'icon': 'circle filled text',
                        'mandatoryForEntity': False,
                        'mandatoryForEvent': False,
                        'name': 'Storyline',
                        'sortOrder': 0
                        })

        if self._typeCharacterGuid is None:
            self._typeCharacterGuid = get_uid('_typeCharacterGuid')
            self._roleCharacterGuid = get_uid('_roleCharacterGuid')
            typeCount = len(self._jsonData['template']['types'])
            self._jsonData['template']['types'].append(
                {
                    'color': 'iconRed',
                    'guid': self._typeCharacterGuid,
                    'icon': 'person',
                    'name': self._typeCharacter,
                    'persistent': False,
                    'roles': [
                        {
                            'allowsMultipleForEntity': True,
                            'allowsMultipleForEvent': True,
                            'allowsPercentAllocated': False,
                            'guid': self._roleCharacterGuid,
                            'icon': 'circle text',
                            'mandatoryForEntity': False,
                            'mandatoryForEvent': False,
                            'name': self._roleCharacter,
                            'sortOrder': 0
                        }
                    ],
                    'sortOrder': typeCount
                })

        if self._typeLocationGuid is None:
            self._typeLocationGuid = get_uid('_typeLocationGuid')
            self._roleLocationGuid = get_uid('_roleLocationGuid')
            typeCount = len(self._jsonData['template']['types'])
            self._jsonData['template']['types'].append(
                {
                    'color': 'iconOrange',
                    'guid': self._typeLocationGuid,
                    'icon': 'map',
                    'name': self._typeLocation,
                    'persistent': True,
                    'roles': [
                        {
                            'allowsMultipleForEntity': True,
                            'allowsMultipleForEvent': True,
                            'allowsPercentAllocated': False,
                            'guid': self._roleLocationGuid,
                            'icon': 'circle text',
                            'mandatoryForEntity': False,
                            'mandatoryForEvent': False,
                            'name': self._roleLocation,
                            'sortOrder': 0
                        }
                    ],
                    'sortOrder': typeCount
                })

        if self._typeItemGuid is None:
            self._typeItemGuid = get_uid('_typeItemGuid')
            self._roleItemGuid = get_uid('_roleItemGuid')
            typeCount = len(self._jsonData['template']['types'])
            self._jsonData['template']['types'].append(
                {
                    'color': 'iconPurple',
                    'guid': self._typeItemGuid,
                    'icon': 'cube',
                    'name': self._typeItem,
                    'persistent': True,
                    'roles': [
                        {
                            'allowsMultipleForEntity': True,
                            'allowsMultipleForEvent': True,
                            'allowsPercentAllocated': False,
                            'guid': self._roleItemGuid,
                            'icon': 'circle text',
                            'mandatoryForEntity': False,
                            'mandatoryForEvent': False,
                            'name': self._roleItem,
                            'sortOrder': 0
                        }
                    ],
                    'sortOrder': typeCount
                })


        targetScIdByTitle = {}
        for scId in self.novel.scenes:
            title = self.novel.scenes[scId].title
            if title:
                if title in targetScIdByTitle:
                    raise Error(_('Ambiguous yWriter scene title "{}".').format(title))

                targetScIdByTitle[title] = scId

        targetCrIdByTitle = {}
        for crId in self.novel.characters:
            title = self.novel.characters[crId].title
            if title:
                if title in targetCrIdByTitle:
                    raise Error(_('Ambiguous yWriter character "{}".').format(title))

                targetCrIdByTitle[title] = crId

        targetLcIdByTitle = {}
        for lcId in self.novel.locations:
            title = self.novel.locations[lcId].title
            if title:
                if title in targetLcIdByTitle:
                    raise Error(_('Ambiguous yWriter location "{}".').format(title))

                targetLcIdByTitle[title] = lcId

        targetItIdByTitle = {}
        for itId in self.novel.items:
            title = self.novel.items[itId].title
            if title:
                if title in targetItIdByTitle:
                    raise Error(_('Ambiguous yWriter item "{}".').format(title))

                targetItIdByTitle[title] = itId

        crIdsByGuid = {}
        lcIdsByGuid = {}
        itIdsByGuid = {}

        characterNames = []
        locationNames = []
        itemNames = []

        for ent in self._jsonData['entities']:
            if ent['entityType'] == self._typeArcGuid:
                self._arcCount += 1
                if ent['name'] == self._entityNarrative:
                    self._entityNarrativeGuid = ent['guid']
                else:
                    self._arcGuidsByName[ent['name']] = ent['guid']

            elif ent['entityType'] == self._typeCharacterGuid:
                if ent['name'] in characterNames:
                    raise Error(_('Ambiguous Aeon character "{}".').format(ent['name']))

                characterNames.append(ent['name'])
                if ent['name'] in targetCrIdByTitle:
                    crId = targetCrIdByTitle[ent['name']]
                else:
                    crId = create_id(self.novel.characters)
                    self.novel.characters[crId] = Character()
                    self.novel.characters[crId].title = ent['name']
                    self.novel.srtCharacters.append(crId)
                crIdsByGuid[ent['guid']] = crId
                self._characterGuidById[crId] = ent['guid']
                if ent['notes']:
                    self.novel.characters[crId].notes = ent['notes']
                else:
                    ent['notes'] = ''

                for fieldName in self.CRT_KWVAR:
                    self.novel.characters[crId].kwVar[fieldName] = None

            elif ent['entityType'] == self._typeLocationGuid:
                if ent['name'] in locationNames:
                    raise Error(_('Ambiguous Aeon location "{}".').format(ent['name']))

                locationNames.append(ent['name'])
                if ent['name'] in targetLcIdByTitle:
                    lcId = targetLcIdByTitle[ent['name']]
                else:
                    lcId = create_id(self.novel.locations)
                    self.novel.locations[lcId] = WorldElement()
                    self.novel.locations[lcId].title = ent['name']
                    self.novel.srtLocations.append(lcId)
                lcIdsByGuid[ent['guid']] = lcId
                self._locationGuidById[lcId] = ent['guid']

                for fieldName in self.LOC_KWVAR:
                    self.novel.locations[lcId].kwVar[fieldName] = None

            elif ent['entityType'] == self._typeItemGuid:
                if ent['name'] in itemNames:
                    raise Error(_('Ambiguous Aeon item "{}".').format(ent['name']))

                itemNames.append(ent['name'])
                if ent['name'] in targetItIdByTitle:
                    itId = targetItIdByTitle[ent['name']]
                else:
                    itId = create_id(self.novel.items)
                    self.novel.items[itId] = WorldElement()
                    self.novel.items[itId].title = ent['name']
                    self.novel.srtItems.append(itId)
                itIdsByGuid[ent['guid']] = itId
                self._itemGuidById[itId] = ent['guid']

                for fieldName in self.ITM_KWVAR:
                    self.novel.items[itId].kwVar[fieldName] = None

        hasPropertyNotes = False
        hasPropertyDesc = False
        for tplPrp in self._jsonData['template']['properties']:
            if tplPrp['name'] == self._propertyDesc:
                self._propertyDescGuid = tplPrp['guid']
                hasPropertyDesc = True
            elif tplPrp['name'] == self._propertyNotes:
                self._propertyNotesGuid = tplPrp['guid']
                hasPropertyNotes = True
            elif tplPrp['name'] == self.PROPERTY_MOONPHASE:
                self._propertyMoonphaseGuid = tplPrp['guid']

        if not hasPropertyNotes:
            for tplPrp in self._jsonData['template']['properties']:
                tplPrp['sortOrder'] += 1
            self._propertyNotesGuid = get_uid('_propertyNotesGuid')
            self._jsonData['template']['properties'].insert(0, {
                'calcMode': 'default',
                'calculate': False,
                'fadeEvents': False,
                'guid': self._propertyNotesGuid,
                'icon': 'tag',
                'isMandatory': False,
                'name': self._propertyNotes,
                'sortOrder': 0,
                'type': 'multitext'
            })
        if not hasPropertyDesc:
            n = len(self._jsonData['template']['properties'])
            self._propertyDescGuid = get_uid('_propertyDescGuid')
            self._jsonData['template']['properties'].append({
                'calcMode': 'default',
                'calculate': False,
                'fadeEvents': False,
                'guid': self._propertyDescGuid,
                'icon': 'tag',
                'isMandatory': False,
                'name': self._propertyDesc,
                'sortOrder': n,
                'type': 'multitext'
            })
        if self._addMoonphase and self._propertyMoonphaseGuid is None:
            n = len(self._jsonData['template']['properties'])
            self._propertyMoonphaseGuid = get_uid('_propertyMoonphaseGuid')
            self._jsonData['template']['properties'].append({
                'calcMode': 'default',
                'calculate': False,
                'fadeEvents': False,
                'guid': self._propertyMoonphaseGuid,
                'icon': 'flag',
                'isMandatory': False,
                'name': self.PROPERTY_MOONPHASE,
                'sortOrder': n,
                'type': 'text'
            })

        scIdsByDate = {}
        scnTitles = []
        narrativeEvents = []
        for evt in self._jsonData['events']:

            isNarrative = False
            for evtRel in evt['relationships']:
                if evtRel['role'] == self._roleArcGuid:
                    if self._entityNarrativeGuid and evtRel['entity'] == self._entityNarrativeGuid:
                        isNarrative = True

            if evt['title'] in scnTitles:
                raise Error(f'Ambiguous Aeon event title "{evt["title"]}".')

            evt['title'] = evt['title'].strip()
            scnTitles.append(evt['title'])
            if evt['title'] in targetScIdByTitle:
                scId = targetScIdByTitle[evt['title']]
            else:
                if self._scenesOnly and not isNarrative:
                    continue

                scId = create_id(self.novel.scenes)
                self.novel.scenes[scId] = Scene()
                self.novel.scenes[scId].title = evt['title']
                self.novel.scenes[scId].status = 1

            narrativeEvents.append(scId)
            displayId = float(evt['displayId'])
            if displayId > self._displayIdMax:
                self._displayIdMax = displayId

            for fieldName in self.SCN_KWVAR:
                self.novel.scenes[scId].kwVar[fieldName] = self.novel.scenes[scId].kwVar.get(fieldName, None)

            hasDescription = False
            hasNotes = False
            for evtVal in evt['values']:

                if evtVal['property'] == self._propertyDescGuid:
                    hasDescription = True
                    if evtVal['value']:
                        self.novel.scenes[scId].desc = evtVal['value']

                elif evtVal['property'] == self._propertyNotesGuid:
                    hasNotes = True
                    if evtVal['value']:
                        self.novel.scenes[scId].notes = evtVal['value']

            if not hasDescription:
                evt['values'].append({'property': self._propertyDescGuid, 'value': ''})
            if not hasNotes:
                evt['values'].append({'property': self._propertyNotesGuid, 'value': ''})

            if evt['tags']:
                self.novel.scenes[scId].tags = []
                for evtTag in evt['tags']:
                    self.novel.scenes[scId].tags.append(evtTag)

            timestamp = 0
            for evtRgv in evt['rangeValues']:
                if evtRgv['rangeProperty'] == self._tplDateGuid:
                    timestamp = evtRgv['position']['timestamp']
                    if timestamp >= self.DATE_LIMIT:
                        sceneStart = datetime.min + timedelta(seconds=timestamp)
                        startDateTime = sceneStart.isoformat().split('T')

                        if self.novel.scenes[scId].day is not None:
                            sceneDelta = sceneStart - self.referenceDate
                            self.novel.scenes[scId].day = str(sceneDelta.days)
                        elif (self.novel.scenes[scId].time is not None) and (self.novel.scenes[scId].date is None):
                            self.novel.scenes[scId].day = '0'
                        else:
                            self.novel.scenes[scId].date = startDateTime[0]
                        self.novel.scenes[scId].time = startDateTime[1]

                        if 'years' in evtRgv['span'] or 'months' in evtRgv['span']:
                            endYear = sceneStart.year
                            endMonth = sceneStart.month
                            if 'years' in evtRgv['span']:
                                endYear += evtRgv['span']['years']
                            if 'months' in evtRgv['span']:
                                endMonth += evtRgv['span']['months']
                                while endMonth > 12:
                                    endMonth -= 12
                                    endYear += 1
                            sceneEnd = datetime(endYear, endMonth, sceneStart.day)
                            sceneDuration = sceneEnd - datetime(sceneStart.year, sceneStart.month, sceneStart.day)
                            lastsDays = sceneDuration.days
                            lastsHours = sceneDuration.seconds // 3600
                            lastsMinutes = (sceneDuration.seconds % 3600) // 60
                        else:
                            lastsDays = 0
                            lastsHours = 0
                            lastsMinutes = 0
                        if 'weeks' in evtRgv['span']:
                            lastsDays += evtRgv['span']['weeks'] * 7
                        if 'days' in evtRgv['span']:
                            lastsDays += evtRgv['span']['days']
                        if 'hours' in evtRgv['span']:
                            lastsDays += evtRgv['span']['hours'] // 24
                            lastsHours += evtRgv['span']['hours'] % 24
                        if 'minutes' in evtRgv['span']:
                            lastsHours += evtRgv['span']['minutes'] // 60
                            lastsMinutes += evtRgv['span']['minutes'] % 60
                        if 'seconds' in evtRgv['span']:
                            lastsMinutes += evtRgv['span']['seconds'] // 60
                        lastsHours += lastsMinutes // 60
                        lastsMinutes %= 60
                        lastsDays += lastsHours // 24
                        lastsHours %= 24
                        self.novel.scenes[scId].lastsDays = str(lastsDays)
                        self.novel.scenes[scId].lastsHours = str(lastsHours)
                        self.novel.scenes[scId].lastsMinutes = str(lastsMinutes)
                    break

            if not timestamp in scIdsByDate:
                scIdsByDate[timestamp] = []
            scIdsByDate[timestamp].append(scId)

            self.novel.scenes[scId].scType = 1
            self.novel.scenes[scId].characters = None
            self.novel.scenes[scId].locations = None
            self.novel.scenes[scId].items = None
            scnArcs = []
            for evtRel in evt['relationships']:
                if evtRel['role'] == self._roleArcGuid:
                    if self._entityNarrativeGuid and evtRel['entity'] == self._entityNarrativeGuid:
                        self.novel.scenes[scId].scType = 0
                        if timestamp > self._timestampMax:
                            self._timestampMax = timestamp
                if evtRel['role'] == self._roleStorylineGuid:
                    for arcName in self._arcGuidsByName:
                        if evtRel['entity'] == self._arcGuidsByName[arcName]:
                            scnArcs.append(arcName)
                elif evtRel['role'] == self._roleCharacterGuid:
                    if self.novel.scenes[scId].characters is None:
                        self.novel.scenes[scId].characters = []
                    crId = crIdsByGuid[evtRel['entity']]
                    self.novel.scenes[scId].characters.append(crId)
                elif evtRel['role'] == self._roleLocationGuid:
                    if self.novel.scenes[scId].locations is None:
                        self.novel.scenes[scId].locations = []
                    lcId = lcIdsByGuid[evtRel['entity']]
                    self.novel.scenes[scId].locations.append(lcId)
                elif evtRel['role'] == self._roleItemGuid:
                    if self.novel.scenes[scId].items is None:
                        self.novel.scenes[scId].items = []
                    itId = itIdsByGuid[evtRel['entity']]
                    self.novel.scenes[scId].items.append(itId)

            self.novel.scenes[scId].scnArcs = list_to_string(scnArcs)

        for scId in self.novel.scenes:
            if not scId in narrativeEvents:
                if self.novel.scenes[scId].scType == 0:
                    self.novel.scenes[scId].scType = 3

        scenesInChapters = []
        for chId in self.novel.srtChapters:
            scenesInChapters.extend(self.novel.chapters[chId].srtScenes)

        newChapterId = create_id(self.novel.srtChapters)
        newChapter = Chapter()
        newChapter.title = _('New scenes')
        newChapter.chType = 0

        srtScenes = sorted(scIdsByDate.items())
        for __, scList in srtScenes:
            for scId in scList:
                if not scId in scenesInChapters:
                    if not newChapterId in self.novel.srtChapters:
                        self.novel.chapters[newChapterId] = newChapter
                        self.novel.srtChapters.append(newChapterId)
                    self.novel.chapters[newChapterId].srtScenes.append(scId)

        if self._timestampMax == 0:
            self._timestampMax = (self.referenceDate - datetime.min).total_seconds()

    def write(self):

        def get_timestamp(scene):
            self._timestampMax += 1
            timestamp = int(self._timestampMax)
            try:
                if scene.date:
                    isoDt = scene.date
                    if scene.time:
                        isoDt = (f'{isoDt} {scene.time}')
                timestamp = int((datetime.fromisoformat(isoDt) - datetime.min).total_seconds())
            except:
                pass
            return timestamp

        def get_span(scene):
            span = {}
            if scene.lastsDays:
                span['days'] = int(scene.lastsDays)
            if scene.lastsHours:
                span['hours'] = int(scene.lastsHours)
            if scene.lastsMinutes:
                span['minutes'] = int(scene.lastsMinutes)
            return span

        def get_display_id():
            self._displayIdMax += 1
            return str(int(self._displayIdMax))

        def build_event(scene):
            event = {
                'attachments': [],
                'color': '',
                'displayId': get_display_id(),
                'guid': get_uid(f'scene{scene.title}'),
                'links': [],
                'locked': False,
                'priority': 500,
                'rangeValues': [{
                    'minimumZoom':-1,
                    'position': {
                        'precision': 'minute',
                        'timestamp': self.DATE_LIMIT
                    },
                    'rangeProperty': self._tplDateGuid,
                    'span': {},
                }],
                'relationships': [],
                'tags': [],
                'title': scene.title,
                'values': [{
                    'property': self._propertyNotesGuid,
                    'value': ''
                },
                    {
                    'property': self._propertyDescGuid,
                    'value': ''
                }],
            }
            if scene.scType == 1:
                event['color'] = self._colors[self._eventColor]
            elif scene.scType == 2:
                event['color'] = self._colors[self._pointColor]
            else:
                event['color'] = self._colors[self._sceneColor]
            return event

        source = self.novel
        self.novel = Novel()
        self.read()

        targetEvents = []
        for evt in self._jsonData['events']:
            targetEvents.append(evt['title'])

        linkedCharacters = []
        linkedLocations = []
        linkedItems = []

        srcScnTitles = []
        for chId in source.chapters:
            if source.chapters[chId].isTrash:
                continue

            for scId in source.chapters[chId].srtScenes:
                if source.scenes[scId].title in srcScnTitles:
                    raise Error(_('Ambiguous yWriter scene title "{}".').format(source.scenes[scId].title))

                srcScnTitles.append(source.scenes[scId].title)

                if source.scenes[scId].characters:
                    linkedCharacters = list(set(linkedCharacters + source.scenes[scId].characters))
                if source.scenes[scId].locations:
                    linkedLocations = list(set(linkedLocations + source.scenes[scId].locations))
                if source.scenes[scId].items:
                    linkedItems = list(set(linkedItems + source.scenes[scId].items))

                arcs = string_to_list(source.scenes[scId].scnArcs)
                for arc in arcs:
                    if not arc in self._arcGuidsByName:
                        self._arcGuidsByName[arc] = None

        srcChrNames = []
        for crId in source.characters:
            if not crId in linkedCharacters:
                continue

            if source.characters[crId].title in srcChrNames:
                raise Error(_('Ambiguous yWriter character "{}".').format(source.characters[crId].title))

            srcChrNames.append(source.characters[crId].title)

        srcLocTitles = []
        for lcId in source.locations:
            if not lcId in linkedLocations:
                continue

            if source.locations[lcId].title in srcLocTitles:
                raise Error(_('Ambiguous yWriter location "{}".').format(source.locations[lcId].title))

            srcLocTitles.append(source.locations[lcId].title)

        srcItmTitles = []
        for itId in source.items:
            if not itId in linkedItems:
                continue

            if source.items[itId].title in srcItmTitles:
                raise Error(_('Ambiguous yWriter item "{}".').format(source.items[itId].title))

            srcItmTitles.append(source.items[itId].title)

        scIdsByTitle = {}
        for scId in self.novel.scenes:
            if self.novel.scenes[scId].title in scIdsByTitle:
                raise Error(_('Ambiguous Aeon event title "{}".').format(self.novel.scenes[scId].title))

            scIdsByTitle[self.novel.scenes[scId].title] = scId

            if not self.novel.scenes[scId].title in srcScnTitles:
                if not self.novel.scenes[scId].scType == 1:
                    self._trashEvents.append(scId)

        crIdsByTitle = {}
        for crId in self.novel.characters:
            if self.novel.characters[crId].title in crIdsByTitle:
                raise Error(_('Ambiguous Aeon character "{}".').format(self.novel.characters[crId].title))

            crIdsByTitle[self.novel.characters[crId].title] = crId

        lcIdsByTitle = {}
        for lcId in self.novel.locations:
            if self.novel.locations[lcId].title in lcIdsByTitle:
                raise Error(_('Ambiguous Aeon location "{}".').format(self.novel.locations[lcId].title))

            lcIdsByTitle[self.novel.locations[lcId].title] = lcId

        itIdsByTitle = {}
        for itId in self.novel.items:
            if self.novel.items[itId].title in itIdsByTitle:
                raise Error(_('Ambiguous Aeon item "{}".').format(self.novel.items[itId].title))

            itIdsByTitle[self.novel.items[itId].title] = itId

        crIdMax = len(self.novel.characters)
        crIdsBySrcId = {}
        for srcCrId in source.characters:
            if source.characters[srcCrId].title in crIdsByTitle:
                crIdsBySrcId[srcCrId] = crIdsByTitle[source.characters[srcCrId].title]
            elif srcCrId in linkedCharacters:
                crIdMax += 1
                crId = str(crIdMax)
                crIdsBySrcId[srcCrId] = crId
                self.novel.characters[crId] = source.characters[srcCrId]
                newGuid = get_uid(f'{crId}{self.novel.characters[crId].title}')
                self._characterGuidById[crId] = newGuid
                self._jsonData['entities'].append(
                    {
                        'entityType': self._typeCharacterGuid,
                        'guid': newGuid,
                        'icon': 'person',
                        'name': self.novel.characters[crId].title,
                        'notes': '',
                        'sortOrder': crIdMax - 1,
                        'swatchColor': 'darkPink'
                    })

        lcIdMax = len(self.novel.locations)
        lcIdsBySrcId = {}
        for srcLcId in source.locations:
            if source.locations[srcLcId].title in lcIdsByTitle:
                lcIdsBySrcId[srcLcId] = lcIdsByTitle[source.locations[srcLcId].title]
            elif srcLcId in linkedLocations:
                lcIdMax += 1
                lcId = str(lcIdMax)
                lcIdsBySrcId[srcLcId] = lcId
                self.novel.locations[lcId] = source.locations[srcLcId]
                newGuid = get_uid(f'{lcId}{self.novel.locations[lcId].title}')
                self._locationGuidById[lcId] = newGuid
                self._jsonData['entities'].append(
                    {
                        'entityType': self._typeLocationGuid,
                        'guid': newGuid,
                        'icon': 'map',
                        'name': self.novel.locations[lcId].title,
                        'notes': '',
                        'sortOrder': lcIdMax - 1,
                        'swatchColor': 'orange'
                    })

        itIdMax = len(self.novel.items)
        itIdsBySrcId = {}
        for srcItId in source.items:
            if source.items[srcItId].title in itIdsByTitle:
                itIdsBySrcId[srcItId] = itIdsByTitle[source.items[srcItId].title]
            elif srcItId in linkedItems:
                itIdMax += 1
                itId = str(itIdMax)
                itIdsBySrcId[srcItId] = itId
                self.novel.items[itId] = source.items[srcItId]
                newGuid = get_uid(f'{itId}{self.novel.items[itId].title}')
                self._itemGuidById[itId] = newGuid
                self._jsonData['entities'].append(
                    {
                        'entityType': self._typeItemGuid,
                        'guid': newGuid,
                        'icon': 'cube',
                        'name': self.novel.items[itId].title,
                        'notes': '',
                        'sortOrder': itIdMax - 1,
                        'swatchColor': 'denim'
                    })

        totalEvents = len(self._jsonData['events'])
        for chId in source.chapters:
            for srcId in source.chapters[chId].srtScenes:
                if source.scenes[srcId].scType == 3:
                    if source.scenes[srcId].title in scIdsByTitle:
                        scId = scIdsByTitle[source.scenes[srcId].title]
                        self.novel.scenes[scId].scType = 1
                    continue

                if source.scenes[srcId].scType == 1 and self._scenesOnly:
                    if source.scenes[srcId].title in scIdsByTitle:
                        scId = scIdsByTitle[source.scenes[srcId].title]
                        self.novel.scenes[scId].scType = 1
                    continue

                if source.scenes[srcId].scType == 2 and source.scenes[srcId].scnArcs is None:
                    if source.scenes[srcId].title in scIdsByTitle:
                        scId = scIdsByTitle[source.scenes[srcId].title]
                        self.novel.scenes[scId].scType = 1
                    continue

                if source.scenes[srcId].title in scIdsByTitle:
                    scId = scIdsByTitle[source.scenes[srcId].title]
                elif source.scenes[srcId].title in targetEvents:
                    continue

                else:
                    totalEvents += 1
                    scId = str(totalEvents)
                    self.novel.scenes[scId] = Scene()
                    self.novel.scenes[scId].title = source.scenes[srcId].title
                    scIdsByTitle[self.novel.scenes[scId].title] = scId
                    self.novel.scenes[scId].scType = source.scenes[srcId].scType
                    newEvent = build_event(self.novel.scenes[scId])
                    self._jsonData['events'].append(newEvent)
                self.novel.scenes[scId].status = source.scenes[srcId].status

                if source.scenes[srcId].scType is not None:
                    self.novel.scenes[scId].scType = source.scenes[srcId].scType

                if source.scenes[srcId].tags is not None:
                    self.novel.scenes[scId].tags = source.scenes[srcId].tags

                if source.scenes[srcId].desc is not None:
                    self.novel.scenes[scId].desc = source.scenes[srcId].desc

                if source.scenes[srcId].characters is not None:
                    self.novel.scenes[scId].characters = []
                    for crId in source.scenes[srcId].characters:
                        if crId in crIdsBySrcId:
                            self.novel.scenes[scId].characters.append(crIdsBySrcId[crId])

                if source.scenes[srcId].locations is not None:
                    self.novel.scenes[scId].locations = []
                    for lcId in source.scenes[srcId].locations:
                        if lcId in lcIdsBySrcId:
                            self.novel.scenes[scId].locations.append(lcIdsBySrcId[lcId])

                if source.scenes[srcId].items is not None:
                    self.novel.scenes[scId].items = []
                    for itId in source.scenes[srcId].items:
                        if itId in itIdsBySrcId:
                            self.novel.scenes[scId].items.append(itIdsBySrcId[itId])

                self.novel.scenes[scId].scnArcs = source.scenes[srcId].scnArcs

                if source.scenes[srcId].time is not None:
                    self.novel.scenes[scId].time = source.scenes[srcId].time

                if source.scenes[srcId].day is not None:
                    dayInt = int(source.scenes[srcId].day)
                    sceneDelta = timedelta(days=dayInt)
                    self.novel.scenes[scId].date = (self.referenceDate + sceneDelta).isoformat().split('T')[0]
                elif (source.scenes[srcId].date is None) and (source.scenes[srcId].time is not None):
                    self.novel.scenes[scId].date = self.referenceDate.isoformat().split('T')[0]
                else:
                    self.novel.scenes[scId].date = source.scenes[srcId].date

                if source.scenes[srcId].lastsMinutes is not None:
                    self.novel.scenes[scId].lastsMinutes = source.scenes[srcId].lastsMinutes
                if source.scenes[srcId].lastsHours is not None:
                    self.novel.scenes[scId].lastsHours = source.scenes[srcId].lastsHours
                if source.scenes[srcId].lastsDays is not None:
                    self.novel.scenes[scId].lastsDays = source.scenes[srcId].lastsDays

                for fieldName in self.SCN_KWVAR:
                    try:
                        self.novel.scenes[scId].kwVar[fieldName] = source.scenes[srcId].kwVar[fieldName]
                    except:
                        pass


        if self._entityNarrativeGuid is None:
            self._entityNarrativeGuid = get_uid('entityNarrativeGuid')
            self._jsonData['entities'].append(
                {
                    'entityType': self._typeArcGuid,
                    'guid': self._entityNarrativeGuid,
                    'icon': 'book',
                    'name': self._entityNarrative,
                    'notes': '',
                    'sortOrder': self._arcCount,
                    'swatchColor': 'orange'
                })
            self._arcCount += 1
        narrativeArc = {
            'entity': self._entityNarrativeGuid,
            'percentAllocated': 1,
            'role': self._roleArcGuid,
        }

        arcs = {}
        for arcName in self._arcGuidsByName:
            if self._arcGuidsByName[arcName] is None:
                guid = get_uid(f'entity{arcName}ArcGuid')
                self._arcGuidsByName[arcName] = guid
                self._jsonData['entities'].append(
                    {
                        'entityType': self._typeArcGuid,
                        'guid': guid,
                        'icon': 'book',
                        'name': arcName,
                        'notes': '',
                        'sortOrder': self._arcCount,
                        'swatchColor': 'orange'
                    })
                self._arcCount += 1
            arcs[arcName] = {
                'entity': self._arcGuidsByName[arcName],
                'percentAllocated': 1,
                'role': self._roleStorylineGuid,
            }

        for evt in self._jsonData['events']:
            try:
                scId = scIdsByTitle[evt['title']]
            except KeyError:
                continue

            if evt['rangeValues'][0]['position']['timestamp'] >= self.DATE_LIMIT:
                evt['rangeValues'][0]['span'] = get_span(self.novel.scenes[scId])
                evt['rangeValues'][0]['position']['timestamp'] = get_timestamp(self.novel.scenes[scId])

            if self._propertyMoonphaseGuid is not None:
                eventMoonphase = get_moon_phase_plus(self.novel.scenes[scId].date)
            else:
                eventMoonphase = ''

            hasMoonphase = False
            for evtVal in evt['values']:

                if evtVal['property'] == self._propertyDescGuid:
                    if self.novel.scenes[scId].desc:
                        evtVal['value'] = self.novel.scenes[scId].desc

                elif evtVal['property'] == self._propertyNotesGuid:
                    if self.novel.scenes[scId].notes:
                        evtVal['value'] = self.novel.scenes[scId].notes

                elif evtVal['property'] == self._propertyMoonphaseGuid:
                        evtVal['value'] = eventMoonphase
                        hasMoonphase = True

            if not hasMoonphase and self._propertyMoonphaseGuid is not None:
                evt['values'].append({'property': self._propertyMoonphaseGuid, 'value': eventMoonphase})

            if self.novel.scenes[scId].tags:
                evt['tags'] = self.novel.scenes[scId].tags

            newRel = []
            for evtRel in evt['relationships']:
                if evtRel['role'] == self._roleCharacterGuid:
                    continue

                elif evtRel['role'] == self._roleLocationGuid:
                    continue

                elif evtRel['role'] == self._roleItemGuid:
                    continue

                else:
                    newRel.append(evtRel)

            if self.novel.scenes[scId].characters:
                for crId in self.novel.scenes[scId].characters:
                    newRel.append(
                        {
                            'entity': self._characterGuidById[crId],
                            'percentAllocated': 1,
                            'role': self._roleCharacterGuid,
                        })

            if self.novel.scenes[scId].locations:
                for lcId in self.novel.scenes[scId].locations:
                    newRel.append(
                        {
                            'entity': self._locationGuidById[lcId],
                            'percentAllocated': 1,
                            'role': self._roleLocationGuid,
                        })

            if self.novel.scenes[scId].items:
                for itId in self.novel.scenes[scId].items:
                    newRel.append(
                        {
                            'entity': self._itemGuidById[itId],
                            'percentAllocated': 1,
                            'role': self._roleItemGuid,
                        })

            evt['relationships'] = newRel

            if self.novel.scenes[scId].scType == 0:
                if narrativeArc not in evt['relationships']:
                    evt['relationships'].append(narrativeArc)

                sceneArcs = string_to_list(self.novel.scenes[scId].scnArcs)
                for arcName in arcs:
                    if arcName in sceneArcs:
                        if arcs[arcName] not in evt['relationships']:
                            evt['relationships'].append(arcs[arcName])
                    else:
                        try:
                            evt['relationships'].remove(arcs[arcName])
                        except:
                            pass

            elif self.novel.scenes[scId].scType == 2:
                if narrativeArc in evt['relationships']:
                    evt['relationships'].remove(narrativeArc)

                sceneArcs = string_to_list(self.novel.scenes[scId].scnArcs)
                for arcName in arcs:
                    if arcName in sceneArcs:
                        if arcs[arcName] not in evt['relationships']:
                            evt['relationships'].append(arcs[arcName])
                    else:
                        try:
                            evt['relationships'].remove(arcs[arcName])
                        except:
                            pass

            elif self.novel.scenes[scId].scType == 1:
                if narrativeArc in evt['relationships']:
                    evt['relationships'].remove(narrativeArc)

                sceneArcs = string_to_list(self.novel.scenes[scId].scnArcs)
                for arcName in sceneArcs:
                    evt['relationships'].remove(arcs[arcName])

        events = []
        for evt in self._jsonData['events']:
            try:
                scId = scIdsByTitle[evt['title']]
            except KeyError:
                events.append(evt)
            else:
                if not scId in self._trashEvents:
                    events.append(evt)
        self._jsonData['events'] = events
        save_timeline(self._jsonData, self.filePath)
from html import unescape
from datetime import datetime
import xml.etree.ElementTree as ET


def indent(elem, level=0):
    i = f'\n{level * "  "}'
    if elem:
        if not elem.text or not elem.text.strip():
            elem.text = f'{i}  '
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            indent(elem, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


class Yw7File(File):
    DESCRIPTION = _('yWriter 7 project')
    EXTENSION = '.yw7'
    _CDATA_TAGS = ['Title', 'AuthorName', 'Bio', 'Desc',
                   'FieldTitle1', 'FieldTitle2', 'FieldTitle3',
                   'FieldTitle4', 'LaTeXHeaderFile', 'Tags',
                   'AKA', 'ImageFile', 'FullName', 'Goals',
                   'Notes', 'RTFFile', 'SceneContent',
                   'Outcome', 'Goal', 'Conflict']

    PRJ_KWVAR = [
        'Field_LanguageCode',
        'Field_CountryCode',
        ]
    SCN_KWVAR = [
        'Field_SceneArcs',
        'Field_SceneStyle',
        ]

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self.tree = None

    def adjust_scene_types(self):
        for chId in self.novel.srtChapters:
            if self.novel.chapters[chId].chType != 0:
                for scId in self.novel.chapters[chId].srtScenes:
                    self.novel.scenes[scId].scType = self.novel.chapters[chId].chType

    def is_locked(self):
        return os.path.isfile(f'{self.filePath}.lock')

    def read(self):

        def read_project(root):
            xmlProject = root.find('PROJECT')

            if xmlProject.find('Title') is not None:
                self.novel.title = xmlProject.find('Title').text

            if xmlProject.find('AuthorName') is not None:
                self.novel.authorName = xmlProject.find('AuthorName').text

            if xmlProject.find('Bio') is not None:
                self.novel.authorBio = xmlProject.find('Bio').text

            if xmlProject.find('Desc') is not None:
                self.novel.desc = xmlProject.find('Desc').text

            if xmlProject.find('FieldTitle1') is not None:
                self.novel.fieldTitle1 = xmlProject.find('FieldTitle1').text

            if xmlProject.find('FieldTitle2') is not None:
                self.novel.fieldTitle2 = xmlProject.find('FieldTitle2').text

            if xmlProject.find('FieldTitle3') is not None:
                self.novel.fieldTitle3 = xmlProject.find('FieldTitle3').text

            if xmlProject.find('FieldTitle4') is not None:
                self.novel.fieldTitle4 = xmlProject.find('FieldTitle4').text

            if xmlProject.find('WordCountStart') is not None:
                try:
                    self.novel.wordCountStart = int(xmlProject.find('WordCountStart').text)
                except:
                    self.novel.wordCountStart = 0
            if xmlProject.find('WordTarget') is not None:
                try:
                    self.novel.wordTarget = int(xmlProject.find('WordTarget').text)
                except:
                    self.novel.wordTarget = 0

            for fieldName in self.PRJ_KWVAR:
                self.novel.kwVar[fieldName] = None

            for prjFields in xmlProject.findall('Fields'):
                for fieldName in self.PRJ_KWVAR:
                    field = prjFields.find(fieldName)
                    if field is not None:
                        self.novel.kwVar[fieldName] = field.text

            if self.novel.kwVar['Field_LanguageCode']:
                self.novel.languageCode = self.novel.kwVar['Field_LanguageCode']
            if self.novel.kwVar['Field_CountryCode']:
                self.novel.countryCode = self.novel.kwVar['Field_CountryCode']

        def read_locations(root):
            self.novel.srtLocations = []
            for xmlLocation in root.find('LOCATIONS'):
                lcId = xmlLocation.find('ID').text
                self.novel.srtLocations.append(lcId)
                self.novel.locations[lcId] = WorldElement()

                if xmlLocation.find('Title') is not None:
                    self.novel.locations[lcId].title = xmlLocation.find('Title').text

                if xmlLocation.find('ImageFile') is not None:
                    self.novel.locations[lcId].image = xmlLocation.find('ImageFile').text

                if xmlLocation.find('Desc') is not None:
                    self.novel.locations[lcId].desc = xmlLocation.find('Desc').text

                if xmlLocation.find('AKA') is not None:
                    self.novel.locations[lcId].aka = xmlLocation.find('AKA').text

                if xmlLocation.find('Tags') is not None:
                    if xmlLocation.find('Tags').text is not None:
                        tags = string_to_list(xmlLocation.find('Tags').text)
                        self.novel.locations[lcId].tags = self._strip_spaces(tags)

                for fieldName in self.LOC_KWVAR:
                    self.novel.locations[lcId].kwVar[fieldName] = None

                for lcFields in xmlLocation.findall('Fields'):
                    for fieldName in self.LOC_KWVAR:
                        field = lcFields.find(fieldName)
                        if field is not None:
                            self.novel.locations[lcId].kwVar[fieldName] = field.text

        def read_items(root):
            self.novel.srtItems = []
            for xmlItem in root.find('ITEMS'):
                itId = xmlItem.find('ID').text
                self.novel.srtItems.append(itId)
                self.novel.items[itId] = WorldElement()

                if xmlItem.find('Title') is not None:
                    self.novel.items[itId].title = xmlItem.find('Title').text

                if xmlItem.find('ImageFile') is not None:
                    self.novel.items[itId].image = xmlItem.find('ImageFile').text

                if xmlItem.find('Desc') is not None:
                    self.novel.items[itId].desc = xmlItem.find('Desc').text

                if xmlItem.find('AKA') is not None:
                    self.novel.items[itId].aka = xmlItem.find('AKA').text

                if xmlItem.find('Tags') is not None:
                    if xmlItem.find('Tags').text is not None:
                        tags = string_to_list(xmlItem.find('Tags').text)
                        self.novel.items[itId].tags = self._strip_spaces(tags)

                for fieldName in self.ITM_KWVAR:
                    self.novel.items[itId].kwVar[fieldName] = None

                for itFields in xmlItem.findall('Fields'):
                    for fieldName in self.ITM_KWVAR:
                        field = itFields.find(fieldName)
                        if field is not None:
                            self.novel.items[itId].kwVar[fieldName] = field.text

        def read_characters(root):
            self.novel.srtCharacters = []
            for xmlCharacter in root.find('CHARACTERS'):
                crId = xmlCharacter.find('ID').text
                self.novel.srtCharacters.append(crId)
                self.novel.characters[crId] = Character()

                if xmlCharacter.find('Title') is not None:
                    self.novel.characters[crId].title = xmlCharacter.find('Title').text

                if xmlCharacter.find('ImageFile') is not None:
                    self.novel.characters[crId].image = xmlCharacter.find('ImageFile').text

                if xmlCharacter.find('Desc') is not None:
                    self.novel.characters[crId].desc = xmlCharacter.find('Desc').text

                if xmlCharacter.find('AKA') is not None:
                    self.novel.characters[crId].aka = xmlCharacter.find('AKA').text

                if xmlCharacter.find('Tags') is not None:
                    if xmlCharacter.find('Tags').text is not None:
                        tags = string_to_list(xmlCharacter.find('Tags').text)
                        self.novel.characters[crId].tags = self._strip_spaces(tags)

                if xmlCharacter.find('Notes') is not None:
                    self.novel.characters[crId].notes = xmlCharacter.find('Notes').text

                if xmlCharacter.find('Bio') is not None:
                    self.novel.characters[crId].bio = xmlCharacter.find('Bio').text

                if xmlCharacter.find('Goals') is not None:
                    self.novel.characters[crId].goals = xmlCharacter.find('Goals').text

                if xmlCharacter.find('FullName') is not None:
                    self.novel.characters[crId].fullName = xmlCharacter.find('FullName').text

                if xmlCharacter.find('Major') is not None:
                    self.novel.characters[crId].isMajor = True
                else:
                    self.novel.characters[crId].isMajor = False

                for fieldName in self.CRT_KWVAR:
                    self.novel.characters[crId].kwVar[fieldName] = None

                for crFields in xmlCharacter.findall('Fields'):
                    for fieldName in self.CRT_KWVAR:
                        field = crFields.find(fieldName)
                        if field is not None:
                            self.novel.characters[crId].kwVar[fieldName] = field.text

        def read_projectnotes(root):
            self.novel.srtPrjNotes = []

            try:
                for xmlProjectnote in root.find('PROJECTNOTES'):
                    if xmlProjectnote.find('ID') is not None:
                        pnId = xmlProjectnote.find('ID').text
                        self.novel.srtPrjNotes.append(pnId)
                        self.novel.projectNotes[pnId] = BasicElement()
                        if xmlProjectnote.find('Title') is not None:
                            self.novel.projectNotes[pnId].title = xmlProjectnote.find('Title').text
                        if xmlProjectnote.find('Desc') is not None:
                            self.novel.projectNotes[pnId].desc = xmlProjectnote.find('Desc').text

                    for fieldName in self.PNT_KWVAR:
                        self.novel.projectNotes[pnId].kwVar[fieldName] = None

                    for pnFields in xmlProjectnote.findall('Fields'):
                        field = pnFields.find(fieldName)
                        if field is not None:
                            self.novel.projectNotes[pnId].kwVar[fieldName] = field.text
            except:
                pass

        def read_projectvars(root):
            try:
                for xmlProjectvar in root.find('PROJECTVARS'):
                    if xmlProjectvar.find('Title') is not None:
                        title = xmlProjectvar.find('Title').text
                        if title == 'Language':
                            if xmlProjectvar.find('Desc') is not None:
                                self.novel.languageCode = xmlProjectvar.find('Desc').text

                        elif title == 'Country':
                            if xmlProjectvar.find('Desc') is not None:
                                self.novel.countryCode = xmlProjectvar.find('Desc').text

                        elif title.startswith('lang='):
                            try:
                                __, langCode = title.split('=')
                                if self.novel.languages is None:
                                    self.novel.languages = []
                                self.novel.languages.append(langCode)
                            except:
                                pass
            except:
                pass

        def read_scenes(root):
            for xmlScene in root.find('SCENES'):
                scId = xmlScene.find('ID').text
                self.novel.scenes[scId] = Scene()

                if xmlScene.find('Title') is not None:
                    self.novel.scenes[scId].title = xmlScene.find('Title').text

                if xmlScene.find('Desc') is not None:
                    self.novel.scenes[scId].desc = xmlScene.find('Desc').text

                if xmlScene.find('SceneContent') is not None:
                    sceneContent = xmlScene.find('SceneContent').text
                    if sceneContent is not None:
                        self.novel.scenes[scId].sceneContent = sceneContent



                self.novel.scenes[scId].scType = 0

                for fieldName in self.SCN_KWVAR:
                    self.novel.scenes[scId].kwVar[fieldName] = None

                for scFields in xmlScene.findall('Fields'):
                    for fieldName in self.SCN_KWVAR:
                        field = scFields.find(fieldName)
                        if field is not None:
                            self.novel.scenes[scId].kwVar[fieldName] = field.text

                    if scFields.find('Field_SceneType') is not None:
                        if scFields.find('Field_SceneType').text == '1':
                            self.novel.scenes[scId].scType = 1
                        elif scFields.find('Field_SceneType').text == '2':
                            self.novel.scenes[scId].scType = 2
                if xmlScene.find('Unused') is not None:
                    if self.novel.scenes[scId].scType == 0:
                        self.novel.scenes[scId].scType = 3

                if xmlScene.find('ExportCondSpecific') is None:
                    self.novel.scenes[scId].doNotExport = False
                elif xmlScene.find('ExportWhenRTF') is not None:
                    self.novel.scenes[scId].doNotExport = False
                else:
                    self.novel.scenes[scId].doNotExport = True

                if xmlScene.find('Status') is not None:
                    self.novel.scenes[scId].status = int(xmlScene.find('Status').text)

                if xmlScene.find('Notes') is not None:
                    self.novel.scenes[scId].notes = xmlScene.find('Notes').text

                if xmlScene.find('Tags') is not None:
                    if xmlScene.find('Tags').text is not None:
                        tags = string_to_list(xmlScene.find('Tags').text)
                        self.novel.scenes[scId].tags = self._strip_spaces(tags)

                if xmlScene.find('Field1') is not None:
                    self.novel.scenes[scId].field1 = xmlScene.find('Field1').text

                if xmlScene.find('Field2') is not None:
                    self.novel.scenes[scId].field2 = xmlScene.find('Field2').text

                if xmlScene.find('Field3') is not None:
                    self.novel.scenes[scId].field3 = xmlScene.find('Field3').text

                if xmlScene.find('Field4') is not None:
                    self.novel.scenes[scId].field4 = xmlScene.find('Field4').text

                if xmlScene.find('AppendToPrev') is not None:
                    self.novel.scenes[scId].appendToPrev = True
                else:
                    self.novel.scenes[scId].appendToPrev = False

                if xmlScene.find('SpecificDateTime') is not None:
                    dateTimeStr = xmlScene.find('SpecificDateTime').text

                    try:
                        dateTime = datetime.fromisoformat(dateTimeStr)
                    except:
                        self.novel.scenes[scId].date = ''
                        self.novel.scenes[scId].time = ''
                    else:
                        startDateTime = dateTime.isoformat().split('T')
                        self.novel.scenes[scId].date = startDateTime[0]
                        self.novel.scenes[scId].time = startDateTime[1]
                else:
                    if xmlScene.find('Day') is not None:
                        day = xmlScene.find('Day').text

                        try:
                            int(day)
                        except ValueError:
                            day = ''
                        self.novel.scenes[scId].day = day

                    hasUnspecificTime = False
                    if xmlScene.find('Hour') is not None:
                        hour = xmlScene.find('Hour').text.zfill(2)
                        hasUnspecificTime = True
                    else:
                        hour = '00'
                    if xmlScene.find('Minute') is not None:
                        minute = xmlScene.find('Minute').text.zfill(2)
                        hasUnspecificTime = True
                    else:
                        minute = '00'
                    if hasUnspecificTime:
                        self.novel.scenes[scId].time = f'{hour}:{minute}:00'

                if xmlScene.find('LastsDays') is not None:
                    self.novel.scenes[scId].lastsDays = xmlScene.find('LastsDays').text

                if xmlScene.find('LastsHours') is not None:
                    self.novel.scenes[scId].lastsHours = xmlScene.find('LastsHours').text

                if xmlScene.find('LastsMinutes') is not None:
                    self.novel.scenes[scId].lastsMinutes = xmlScene.find('LastsMinutes').text

                if xmlScene.find('ReactionScene') is not None:
                    self.novel.scenes[scId].isReactionScene = True
                else:
                    self.novel.scenes[scId].isReactionScene = False

                if xmlScene.find('SubPlot') is not None:
                    self.novel.scenes[scId].isSubPlot = True
                else:
                    self.novel.scenes[scId].isSubPlot = False

                if xmlScene.find('Goal') is not None:
                    self.novel.scenes[scId].goal = xmlScene.find('Goal').text

                if xmlScene.find('Conflict') is not None:
                    self.novel.scenes[scId].conflict = xmlScene.find('Conflict').text

                if xmlScene.find('Outcome') is not None:
                    self.novel.scenes[scId].outcome = xmlScene.find('Outcome').text

                if xmlScene.find('ImageFile') is not None:
                    self.novel.scenes[scId].image = xmlScene.find('ImageFile').text

                if xmlScene.find('Characters') is not None:
                    for characters in xmlScene.find('Characters').iter('CharID'):
                        crId = characters.text
                        if crId in self.novel.srtCharacters:
                            if self.novel.scenes[scId].characters is None:
                                self.novel.scenes[scId].characters = []
                            self.novel.scenes[scId].characters.append(crId)

                if xmlScene.find('Locations') is not None:
                    for locations in xmlScene.find('Locations').iter('LocID'):
                        lcId = locations.text
                        if lcId in self.novel.srtLocations:
                            if self.novel.scenes[scId].locations is None:
                                self.novel.scenes[scId].locations = []
                            self.novel.scenes[scId].locations.append(lcId)

                if xmlScene.find('Items') is not None:
                    for items in xmlScene.find('Items').iter('ItemID'):
                        itId = items.text
                        if itId in self.novel.srtItems:
                            if self.novel.scenes[scId].items is None:
                                self.novel.scenes[scId].items = []
                            self.novel.scenes[scId].items.append(itId)

        def read_chapters(root):
            self.novel.srtChapters = []
            for xmlChapter in root.find('CHAPTERS'):
                chId = xmlChapter.find('ID').text
                self.novel.chapters[chId] = Chapter()
                self.novel.srtChapters.append(chId)

                if xmlChapter.find('Title') is not None:
                    self.novel.chapters[chId].title = xmlChapter.find('Title').text

                if xmlChapter.find('Desc') is not None:
                    self.novel.chapters[chId].desc = xmlChapter.find('Desc').text

                if xmlChapter.find('SectionStart') is not None:
                    self.novel.chapters[chId].chLevel = 1
                else:
                    self.novel.chapters[chId].chLevel = 0


                self.novel.chapters[chId].chType = 0
                if xmlChapter.find('Unused') is not None:
                    yUnused = True
                else:
                    yUnused = False
                if xmlChapter.find('ChapterType') is not None:
                    yChapterType = xmlChapter.find('ChapterType').text
                    if yChapterType == '2':
                        self.novel.chapters[chId].chType = 2
                    elif yChapterType == '1':
                        self.novel.chapters[chId].chType = 1
                    elif yUnused:
                        self.novel.chapters[chId].chType = 3
                else:
                    if xmlChapter.find('Type') is not None:
                        yType = xmlChapter.find('Type').text
                        if yType == '1':
                            self.novel.chapters[chId].chType = 1
                        elif yUnused:
                            self.novel.chapters[chId].chType = 3

                self.novel.chapters[chId].suppressChapterTitle = False
                if self.novel.chapters[chId].title is not None:
                    if self.novel.chapters[chId].title.startswith('@'):
                        self.novel.chapters[chId].suppressChapterTitle = True

                for fieldName in self.CHP_KWVAR:
                    self.novel.chapters[chId].kwVar[fieldName] = None

                for chFields in xmlChapter.findall('Fields'):
                    if chFields.find('Field_SuppressChapterTitle') is not None:
                        if chFields.find('Field_SuppressChapterTitle').text == '1':
                            self.novel.chapters[chId].suppressChapterTitle = True
                    self.novel.chapters[chId].isTrash = False
                    if chFields.find('Field_IsTrash') is not None:
                        if chFields.find('Field_IsTrash').text == '1':
                            self.novel.chapters[chId].isTrash = True
                    self.novel.chapters[chId].suppressChapterBreak = False
                    if chFields.find('Field_SuppressChapterBreak') is not None:
                        if chFields.find('Field_SuppressChapterBreak').text == '1':
                            self.novel.chapters[chId].suppressChapterBreak = True

                    for fieldName in self.CHP_KWVAR:
                        field = chFields.find(fieldName)
                        if field is not None:
                            self.novel.chapters[chId].kwVar[fieldName] = field.text

                self.novel.chapters[chId].srtScenes = []
                if xmlChapter.find('Scenes') is not None:
                    for scn in xmlChapter.find('Scenes').findall('ScID'):
                        scId = scn.text
                        if scId in self.novel.scenes:
                            self.novel.chapters[chId].srtScenes.append(scId)

        for field in self.PRJ_KWVAR:
            self.novel.kwVar[field] = None

        if self.is_locked():
            raise Error(f'{_("yWriter seems to be open. Please close first")}.')
        try:
            self.tree = ET.parse(self.filePath)
        except:
            raise Error(f'{_("Can not process file")}: "{norm_path(self.filePath)}".')

        root = self.tree.getroot()
        read_project(root)
        read_locations(root)
        read_items(root)
        read_characters(root)
        read_projectvars(root)
        read_projectnotes(root)
        read_scenes(root)
        read_chapters(root)
        self.adjust_scene_types()

        for scId in self.novel.scenes:
            self.novel.scenes[scId].scnArcs = self.novel.scenes[scId].kwVar.get('Field_SceneArcs', None)
            self.novel.scenes[scId].scnStyle = self.novel.scenes[scId].kwVar.get('Field_SceneStyle', None)

    def write(self):
        if self.is_locked():
            raise Error(f'{_("yWriter seems to be open. Please close first")}.')

        if self.novel.languages is None:
            self.novel.get_languages()

        for scId in self.novel.scenes:
            if self.novel.scenes[scId].scnArcs is not None:
                self.novel.scenes[scId].kwVar['Field_SceneArcs'] = self.novel.scenes[scId].scnArcs
            if self.novel.scenes[scId].scnStyle is not None:
                self.novel.scenes[scId].kwVar['Field_SceneStyle'] = self.novel.scenes[scId].scnStyle

        self._build_element_tree()
        self._write_element_tree(self)
        self._postprocess_xml_file(self.filePath)

    def _build_element_tree(self):

        def set_element(parent, tag, text, index):
            subelement = parent.find(tag)
            if subelement is None:
                if text is not None:
                    subelement = ET.Element(tag)
                    parent.insert(index, subelement)
                    subelement.text = text
                    index += 1
            elif text is not None:
                subelement.text = text
                index += 1
            return index

        def build_scene_subtree(xmlScene, prjScn):

            def remove_date_time():
                if xmlScene.find('SpecificDateTime') is not None:
                    xmlScene.remove(xmlScene.find('SpecificDateTime'))

                if xmlScene.find('SpecificDateMode') is not None:
                    xmlScene.remove(xmlScene.find('SpecificDateMode'))

                if xmlScene.find('Day') is not None:
                    xmlScene.remove(xmlScene.find('Day'))

                if xmlScene.find('Hour') is not None:
                    xmlScene.remove(xmlScene.find('Hour'))

                if xmlScene.find('Minute') is not None:
                    xmlScene.remove(xmlScene.find('Minute'))

            i = 1
            i = set_element(xmlScene, 'Title', prjScn.title, i)

            if xmlScene.find('BelongsToChID') is None:
                for chId in self.novel.chapters:
                    if scId in self.novel.chapters[chId].srtScenes:
                        ET.SubElement(xmlScene, 'BelongsToChID').text = chId
                        break

            if prjScn.desc is not None:
                try:
                    xmlScene.find('Desc').text = prjScn.desc
                except(AttributeError):
                    if prjScn.desc:
                        ET.SubElement(xmlScene, 'Desc').text = prjScn.desc

            if xmlScene.find('SceneContent') is None:
                ET.SubElement(xmlScene, 'SceneContent').text = prjScn.sceneContent

            if xmlScene.find('WordCount') is None:
                ET.SubElement(xmlScene, 'WordCount').text = str(prjScn.wordCount)

            if xmlScene.find('LetterCount') is None:
                ET.SubElement(xmlScene, 'LetterCount').text = str(prjScn.letterCount)


            scTypeEncoding = (
                (False, None),
                (True, '1'),
                (True, '2'),
                (True, '0'),
                )
            if prjScn.scType is None:
                prjScn.scType = 0
            yUnused, ySceneType = scTypeEncoding[prjScn.scType]

            if yUnused:
                if xmlScene.find('Unused') is None:
                    ET.SubElement(xmlScene, 'Unused').text = '-1'
            elif xmlScene.find('Unused') is not None:
                xmlScene.remove(xmlScene.find('Unused'))

            scFields = xmlScene.find('Fields')
            if scFields is not None:
                fieldScType = scFields.find('Field_SceneType')
                if ySceneType is None:
                    if fieldScType is not None:
                        scFields.remove(fieldScType)
                else:
                    try:
                        fieldScType.text = ySceneType
                    except(AttributeError):
                        ET.SubElement(scFields, 'Field_SceneType').text = ySceneType
            elif ySceneType is not None:
                scFields = ET.SubElement(xmlScene, 'Fields')
                ET.SubElement(scFields, 'Field_SceneType').text = ySceneType

            for field in self.SCN_KWVAR:
                if self.novel.scenes[scId].kwVar.get(field, None):
                    if scFields is None:
                        scFields = ET.SubElement(xmlScene, 'Fields')
                    try:
                        scFields.find(field).text = self.novel.scenes[scId].kwVar[field]
                    except(AttributeError):
                        ET.SubElement(scFields, field).text = self.novel.scenes[scId].kwVar[field]
                elif scFields is not None:
                    try:
                        scFields.remove(scFields.find(field))
                    except:
                        pass

            if prjScn.status is not None:
                try:
                    xmlScene.find('Status').text = str(prjScn.status)
                except:
                    ET.SubElement(xmlScene, 'Status').text = str(prjScn.status)

            if prjScn.notes is not None:
                try:
                    xmlScene.find('Notes').text = prjScn.notes
                except(AttributeError):
                    if prjScn.notes:
                        ET.SubElement(xmlScene, 'Notes').text = prjScn.notes

            if prjScn.tags is not None:
                try:
                    xmlScene.find('Tags').text = list_to_string(prjScn.tags)
                except(AttributeError):
                    if prjScn.tags:
                        ET.SubElement(xmlScene, 'Tags').text = list_to_string(prjScn.tags)

            if prjScn.field1 is not None:
                try:
                    xmlScene.find('Field1').text = prjScn.field1
                except(AttributeError):
                    if prjScn.field1:
                        ET.SubElement(xmlScene, 'Field1').text = prjScn.field1

            if prjScn.field2 is not None:
                try:
                    xmlScene.find('Field2').text = prjScn.field2
                except(AttributeError):
                    if prjScn.field2:
                        ET.SubElement(xmlScene, 'Field2').text = prjScn.field2

            if prjScn.field3 is not None:
                try:
                    xmlScene.find('Field3').text = prjScn.field3
                except(AttributeError):
                    if prjScn.field3:
                        ET.SubElement(xmlScene, 'Field3').text = prjScn.field3

            if prjScn.field4 is not None:
                try:
                    xmlScene.find('Field4').text = prjScn.field4
                except(AttributeError):
                    if prjScn.field4:
                        ET.SubElement(xmlScene, 'Field4').text = prjScn.field4

            if prjScn.appendToPrev:
                if xmlScene.find('AppendToPrev') is None:
                    ET.SubElement(xmlScene, 'AppendToPrev').text = '-1'
            elif xmlScene.find('AppendToPrev') is not None:
                xmlScene.remove(xmlScene.find('AppendToPrev'))

            if (prjScn.date is not None) and (prjScn.time is not None):
                separator = ' '
                dateTime = f'{prjScn.date}{separator}{prjScn.time}'

                if dateTime == separator:
                    remove_date_time()

                elif xmlScene.find('SpecificDateTime') is not None:
                    if dateTime.count(':') < 2:
                        dateTime = f'{dateTime}:00'
                    xmlScene.find('SpecificDateTime').text = dateTime
                else:
                    ET.SubElement(xmlScene, 'SpecificDateTime').text = dateTime
                    ET.SubElement(xmlScene, 'SpecificDateMode').text = '-1'

                    if xmlScene.find('Day') is not None:
                        xmlScene.remove(xmlScene.find('Day'))

                    if xmlScene.find('Hour') is not None:
                        xmlScene.remove(xmlScene.find('Hour'))

                    if xmlScene.find('Minute') is not None:
                        xmlScene.remove(xmlScene.find('Minute'))

            elif (prjScn.day is not None) or (prjScn.time is not None):

                if not prjScn.day and not prjScn.time:
                    remove_date_time()

                else:
                    if xmlScene.find('SpecificDateTime') is not None:
                        xmlScene.remove(xmlScene.find('SpecificDateTime'))

                    if xmlScene.find('SpecificDateMode') is not None:
                        xmlScene.remove(xmlScene.find('SpecificDateMode'))
                    if prjScn.day is not None:
                        try:
                            xmlScene.find('Day').text = prjScn.day
                        except(AttributeError):
                            ET.SubElement(xmlScene, 'Day').text = prjScn.day
                    if prjScn.time is not None:
                        hours, minutes, seconds = prjScn.time.split(':')
                        try:
                            xmlScene.find('Hour').text = hours
                        except(AttributeError):
                            ET.SubElement(xmlScene, 'Hour').text = hours
                        try:
                            xmlScene.find('Minute').text = minutes
                        except(AttributeError):
                            ET.SubElement(xmlScene, 'Minute').text = minutes

            if prjScn.lastsDays is not None:
                try:
                    xmlScene.find('LastsDays').text = prjScn.lastsDays
                except(AttributeError):
                    if prjScn.lastsDays:
                        ET.SubElement(xmlScene, 'LastsDays').text = prjScn.lastsDays

            if prjScn.lastsHours is not None:
                try:
                    xmlScene.find('LastsHours').text = prjScn.lastsHours
                except(AttributeError):
                    if prjScn.lastsHours:
                        ET.SubElement(xmlScene, 'LastsHours').text = prjScn.lastsHours

            if prjScn.lastsMinutes is not None:
                try:
                    xmlScene.find('LastsMinutes').text = prjScn.lastsMinutes
                except(AttributeError):
                    if prjScn.lastsMinutes:
                        ET.SubElement(xmlScene, 'LastsMinutes').text = prjScn.lastsMinutes

            if prjScn.isReactionScene:
                if xmlScene.find('ReactionScene') is None:
                    ET.SubElement(xmlScene, 'ReactionScene').text = '-1'
            elif xmlScene.find('ReactionScene') is not None:
                xmlScene.remove(xmlScene.find('ReactionScene'))

            if prjScn.isSubPlot:
                if xmlScene.find('SubPlot') is None:
                    ET.SubElement(xmlScene, 'SubPlot').text = '-1'
            elif xmlScene.find('SubPlot') is not None:
                xmlScene.remove(xmlScene.find('SubPlot'))

            if prjScn.goal is not None:
                try:
                    xmlScene.find('Goal').text = prjScn.goal
                except(AttributeError):
                    if prjScn.goal:
                        ET.SubElement(xmlScene, 'Goal').text = prjScn.goal

            if prjScn.conflict is not None:
                try:
                    xmlScene.find('Conflict').text = prjScn.conflict
                except(AttributeError):
                    if prjScn.conflict:
                        ET.SubElement(xmlScene, 'Conflict').text = prjScn.conflict

            if prjScn.outcome is not None:
                try:
                    xmlScene.find('Outcome').text = prjScn.outcome
                except(AttributeError):
                    if prjScn.outcome:
                        ET.SubElement(xmlScene, 'Outcome').text = prjScn.outcome

            if prjScn.image is not None:
                try:
                    xmlScene.find('ImageFile').text = prjScn.image
                except(AttributeError):
                    if prjScn.image:
                        ET.SubElement(xmlScene, 'ImageFile').text = prjScn.image

            if prjScn.characters is not None:
                xmlCharacters = xmlScene.find('Characters')
                try:
                    for oldCrId in xmlCharacters.findall('CharID'):
                        xmlCharacters.remove(oldCrId)
                except(AttributeError):
                    xmlCharacters = ET.SubElement(xmlScene, 'Characters')
                for crId in prjScn.characters:
                    ET.SubElement(xmlCharacters, 'CharID').text = crId

            if prjScn.locations is not None:
                xmlLocations = xmlScene.find('Locations')
                try:
                    for oldLcId in xmlLocations.findall('LocID'):
                        xmlLocations.remove(oldLcId)
                except(AttributeError):
                    xmlLocations = ET.SubElement(xmlScene, 'Locations')
                for lcId in prjScn.locations:
                    ET.SubElement(xmlLocations, 'LocID').text = lcId

            if prjScn.items is not None:
                xmlItems = xmlScene.find('Items')
                try:
                    for oldItId in xmlItems.findall('ItemID'):
                        xmlItems.remove(oldItId)
                except(AttributeError):
                    xmlItems = ET.SubElement(xmlScene, 'Items')
                for itId in prjScn.items:
                    ET.SubElement(xmlItems, 'ItemID').text = itId


        def build_chapter_subtree(xmlChapter, prjChp, sortOrder):

            chTypeEncoding = (
                (False, '0', '0'),
                (True, '1', '1'),
                (True, '1', '2'),
                (True, '1', '0'),
                )
            if prjChp.chType is None:
                prjChp.chType = 0
            yUnused, yType, yChapterType = chTypeEncoding[prjChp.chType]

            i = 1
            i = set_element(xmlChapter, 'Title', prjChp.title, i)
            i = set_element(xmlChapter, 'Desc', prjChp.desc, i)

            if yUnused:
                if xmlChapter.find('Unused') is None:
                    elem = ET.Element('Unused')
                    elem.text = '-1'
                    xmlChapter.insert(i, elem)
            elif xmlChapter.find('Unused') is not None:
                xmlChapter.remove(xmlChapter.find('Unused'))
            if xmlChapter.find('Unused') is not None:
                i += 1

            i = set_element(xmlChapter, 'SortOrder', str(sortOrder), i)

            chFields = xmlChapter.find('Fields')
            if prjChp.suppressChapterTitle:
                if chFields is None:
                    chFields = ET.Element('Fields')
                    xmlChapter.insert(i, chFields)
                try:
                    chFields.find('Field_SuppressChapterTitle').text = '1'
                except(AttributeError):
                    ET.SubElement(chFields, 'Field_SuppressChapterTitle').text = '1'
            elif chFields is not None:
                if chFields.find('Field_SuppressChapterTitle') is not None:
                    chFields.find('Field_SuppressChapterTitle').text = '0'

            if prjChp.suppressChapterBreak:
                if chFields is None:
                    chFields = ET.Element('Fields')
                    xmlChapter.insert(i, chFields)
                try:
                    chFields.find('Field_SuppressChapterBreak').text = '1'
                except(AttributeError):
                    ET.SubElement(chFields, 'Field_SuppressChapterBreak').text = '1'
            elif chFields is not None:
                if chFields.find('Field_SuppressChapterBreak') is not None:
                    chFields.find('Field_SuppressChapterBreak').text = '0'

            if prjChp.isTrash:
                if chFields is None:
                    chFields = ET.Element('Fields')
                    xmlChapter.insert(i, chFields)
                try:
                    chFields.find('Field_IsTrash').text = '1'
                except(AttributeError):
                    ET.SubElement(chFields, 'Field_IsTrash').text = '1'

            elif chFields is not None:
                if chFields.find('Field_IsTrash') is not None:
                    chFields.remove(chFields.find('Field_IsTrash'))

            for field in self.CHP_KWVAR:
                if prjChp.kwVar.get(field, None):
                    if chFields is None:
                        chFields = ET.Element('Fields')
                        xmlChapter.insert(i, chFields)
                    try:
                        chFields.find(field).text = prjChp.kwVar[field]
                    except(AttributeError):
                        ET.SubElement(chFields, field).text = prjChp.kwVar[field]
                elif chFields is not None:
                    try:
                        chFields.remove(chFields.find(field))
                    except:
                        pass
            if xmlChapter.find('Fields') is not None:
                i += 1

            if xmlChapter.find('SectionStart') is not None:
                if prjChp.chLevel == 0:
                    xmlChapter.remove(xmlChapter.find('SectionStart'))
            elif prjChp.chLevel == 1:
                elem = ET.Element('SectionStart')
                elem.text = '-1'
                xmlChapter.insert(i, elem)
            if xmlChapter.find('SectionStart') is not None:
                i += 1

            i = set_element(xmlChapter, 'Type', yType, i)
            i = set_element(xmlChapter, 'ChapterType', yChapterType, i)

            xmlScnList = xmlChapter.find('Scenes')

            if xmlScnList is not None:
                xmlChapter.remove(xmlScnList)

            if prjChp.srtScenes:
                xmlScnList = ET.Element('Scenes')
                xmlChapter.insert(i, xmlScnList)
                for scId in prjChp.srtScenes:
                    ET.SubElement(xmlScnList, 'ScID').text = scId

        def build_location_subtree(xmlLoc, prjLoc, sortOrder):
            if prjLoc.title is not None:
                ET.SubElement(xmlLoc, 'Title').text = prjLoc.title

            if prjLoc.image is not None:
                ET.SubElement(xmlLoc, 'ImageFile').text = prjLoc.image

            if prjLoc.desc is not None:
                ET.SubElement(xmlLoc, 'Desc').text = prjLoc.desc

            if prjLoc.aka is not None:
                ET.SubElement(xmlLoc, 'AKA').text = prjLoc.aka

            if prjLoc.tags is not None:
                ET.SubElement(xmlLoc, 'Tags').text = list_to_string(prjLoc.tags)

            ET.SubElement(xmlLoc, 'SortOrder').text = str(sortOrder)

            lcFields = xmlLoc.find('Fields')
            for field in self.LOC_KWVAR:
                if self.novel.locations[lcId].kwVar.get(field, None):
                    if lcFields is None:
                        lcFields = ET.SubElement(xmlLoc, 'Fields')
                    try:
                        lcFields.find(field).text = self.novel.xmlLocations[lcId].kwVar[field]
                    except(AttributeError):
                        ET.SubElement(lcFields, field).text = self.novel.xmlLocations[lcId].kwVar[field]
                elif lcFields is not None:
                    try:
                        lcFields.remove(lcFields.find(field))
                    except:
                        pass

        def build_prjNote_subtree(xmlPnt, prjPnt, sortOrder):
            if prjPnt.title is not None:
                ET.SubElement(xmlPnt, 'Title').text = prjPnt.title

            if prjPnt.desc is not None:
                ET.SubElement(xmlPnt, 'Desc').text = prjPnt.desc

            ET.SubElement(xmlPnt, 'SortOrder').text = str(sortOrder)

        def add_projectvariable(title, desc, tags):
            pvId = create_id(prjVars)
            prjVars.append(pvId)
            projectvar = ET.SubElement(projectvars, 'PROJECTVAR')
            ET.SubElement(projectvar, 'ID').text = pvId
            ET.SubElement(projectvar, 'Title').text = title
            ET.SubElement(projectvar, 'Desc').text = desc
            ET.SubElement(projectvar, 'Tags').text = tags

        def build_item_subtree(xmlItm, prjItm, sortOrder):
            if prjItm.title is not None:
                ET.SubElement(xmlItm, 'Title').text = prjItm.title

            if prjItm.image is not None:
                ET.SubElement(xmlItm, 'ImageFile').text = prjItm.image

            if prjItm.desc is not None:
                ET.SubElement(xmlItm, 'Desc').text = prjItm.desc

            if prjItm.aka is not None:
                ET.SubElement(xmlItm, 'AKA').text = prjItm.aka

            if prjItm.tags is not None:
                ET.SubElement(xmlItm, 'Tags').text = list_to_string(prjItm.tags)

            ET.SubElement(xmlItm, 'SortOrder').text = str(sortOrder)

            itFields = xmlItm.find('Fields')
            for field in self.ITM_KWVAR:
                if self.novel.items[itId].kwVar.get(field, None):
                    if itFields is None:
                        itFields = ET.SubElement(xmlItm, 'Fields')
                    try:
                        itFields.find(field).text = self.novel.xmlItems[itId].kwVar[field]
                    except(AttributeError):
                        ET.SubElement(itFields, field).text = self.novel.xmlItems[itId].kwVar[field]
                elif itFields is not None:
                    try:
                        itFields.remove(itFields.find(field))
                    except:
                        pass

        def build_character_subtree(xmlCrt, prjCrt, sortOrder):
            if prjCrt.title is not None:
                ET.SubElement(xmlCrt, 'Title').text = prjCrt.title

            if prjCrt.desc is not None:
                ET.SubElement(xmlCrt, 'Desc').text = prjCrt.desc

            if prjCrt.image is not None:
                ET.SubElement(xmlCrt, 'ImageFile').text = prjCrt.image

            ET.SubElement(xmlCrt, 'SortOrder').text = str(sortOrder)

            if prjCrt.notes is not None:
                ET.SubElement(xmlCrt, 'Notes').text = prjCrt.notes

            if prjCrt.aka is not None:
                ET.SubElement(xmlCrt, 'AKA').text = prjCrt.aka

            if prjCrt.tags is not None:
                ET.SubElement(xmlCrt, 'Tags').text = list_to_string(prjCrt.tags)

            if prjCrt.bio is not None:
                ET.SubElement(xmlCrt, 'Bio').text = prjCrt.bio

            if prjCrt.goals is not None:
                ET.SubElement(xmlCrt, 'Goals').text = prjCrt.goals

            if prjCrt.fullName is not None:
                ET.SubElement(xmlCrt, 'FullName').text = prjCrt.fullName

            if prjCrt.isMajor:
                ET.SubElement(xmlCrt, 'Major').text = '-1'

            crFields = xmlCrt.find('Fields')
            for field in self.CRT_KWVAR:
                if self.novel.characters[crId].kwVar.get(field, None):
                    if crFields is None:
                        crFields = ET.SubElement(xmlCrt, 'Fields')
                    try:
                        crFields.find(field).text = self.novel.xmlCharacters[crId].kwVar[field]
                    except(AttributeError):
                        ET.SubElement(crFields, field).text = self.novel.xmlCharacters[crId].kwVar[field]
                elif crFields is not None:
                    try:
                        crFields.remove(crFields.find(field))
                    except:
                        pass

        def build_project_subtree(xmlProject):
            VER = '7'
            try:
                xmlProject.find('Ver').text = VER
            except(AttributeError):
                ET.SubElement(xmlProject, 'Ver').text = VER

            if self.novel.title is not None:
                try:
                    xmlProject.find('Title').text = self.novel.title
                except(AttributeError):
                    ET.SubElement(xmlProject, 'Title').text = self.novel.title

            if self.novel.desc is not None:
                try:
                    xmlProject.find('Desc').text = self.novel.desc
                except(AttributeError):
                    ET.SubElement(xmlProject, 'Desc').text = self.novel.desc

            if self.novel.authorName is not None:
                try:
                    xmlProject.find('AuthorName').text = self.novel.authorName
                except(AttributeError):
                    ET.SubElement(xmlProject, 'AuthorName').text = self.novel.authorName

            if self.novel.authorBio is not None:
                try:
                    xmlProject.find('Bio').text = self.novel.authorBio
                except(AttributeError):
                    ET.SubElement(xmlProject, 'Bio').text = self.novel.authorBio

            if self.novel.fieldTitle1 is not None:
                try:
                    xmlProject.find('FieldTitle1').text = self.novel.fieldTitle1
                except(AttributeError):
                    ET.SubElement(xmlProject, 'FieldTitle1').text = self.novel.fieldTitle1

            if self.novel.fieldTitle2 is not None:
                try:
                    xmlProject.find('FieldTitle2').text = self.novel.fieldTitle2
                except(AttributeError):
                    ET.SubElement(xmlProject, 'FieldTitle2').text = self.novel.fieldTitle2

            if self.novel.fieldTitle3 is not None:
                try:
                    xmlProject.find('FieldTitle3').text = self.novel.fieldTitle3
                except(AttributeError):
                    ET.SubElement(xmlProject, 'FieldTitle3').text = self.novel.fieldTitle3

            if self.novel.fieldTitle4 is not None:
                try:
                    xmlProject.find('FieldTitle4').text = self.novel.fieldTitle4
                except(AttributeError):
                    ET.SubElement(xmlProject, 'FieldTitle4').text = self.novel.fieldTitle4

            if self.novel.wordCountStart is not None:
                try:
                    xmlProject.find('WordCountStart').text = str(self.novel.wordCountStart)
                except(AttributeError):
                    ET.SubElement(xmlProject, 'WordCountStart').text = str(self.novel.wordCountStart)

            if self.novel.wordTarget is not None:
                try:
                    xmlProject.find('WordTarget').text = str(self.novel.wordTarget)
                except(AttributeError):
                    ET.SubElement(xmlProject, 'WordTarget').text = str(self.novel.wordTarget)


            self.novel.kwVar['Field_LanguageCode'] = None
            self.novel.kwVar['Field_CountryCode'] = None

            prjFields = xmlProject.find('Fields')
            for field in self.PRJ_KWVAR:
                setting = self.novel.kwVar.get(field, None)
                if setting:
                    if prjFields is None:
                        prjFields = ET.SubElement(xmlProject, 'Fields')
                    try:
                        prjFields.find(field).text = setting
                    except(AttributeError):
                        ET.SubElement(prjFields, field).text = setting
                else:
                    try:
                        prjFields.remove(prjFields.find(field))
                    except:
                        pass

        TAG = 'YWRITER7'
        xmlNewScenes = {}
        xmlNewChapters = {}
        try:
            root = self.tree.getroot()
            xmlProject = root.find('PROJECT')
            xmlLocations = root.find('LOCATIONS')
            xmlItems = root.find('ITEMS')
            xmlCharacters = root.find('CHARACTERS')
            xmlProjectnotes = root.find('PROJECTNOTES')
            xmlScenes = root.find('SCENES')
            xmlChapters = root.find('CHAPTERS')
        except(AttributeError):
            root = ET.Element(TAG)
            xmlProject = ET.SubElement(root, 'PROJECT')
            xmlLocations = ET.SubElement(root, 'LOCATIONS')
            xmlItems = ET.SubElement(root, 'ITEMS')
            xmlCharacters = ET.SubElement(root, 'CHARACTERS')
            xmlProjectnotes = ET.SubElement(root, 'PROJECTNOTES')
            xmlScenes = ET.SubElement(root, 'SCENES')
            xmlChapters = ET.SubElement(root, 'CHAPTERS')


        build_project_subtree(xmlProject)


        for xmlLoc in xmlLocations.findall('LOCATION'):
            xmlLocations.remove(xmlLoc)

        sortOrder = 0
        for lcId in self.novel.srtLocations:
            sortOrder += 1
            xmlLoc = ET.SubElement(xmlLocations, 'LOCATION')
            ET.SubElement(xmlLoc, 'ID').text = lcId
            build_location_subtree(xmlLoc, self.novel.locations[lcId], sortOrder)


        for xmlItm in xmlItems.findall('ITEM'):
            xmlItems.remove(xmlItm)

        sortOrder = 0
        for itId in self.novel.srtItems:
            sortOrder += 1
            xmlItm = ET.SubElement(xmlItems, 'ITEM')
            ET.SubElement(xmlItm, 'ID').text = itId
            build_item_subtree(xmlItm, self.novel.items[itId], sortOrder)


        for xmlCrt in xmlCharacters.findall('CHARACTER'):
            xmlCharacters.remove(xmlCrt)

        sortOrder = 0
        for crId in self.novel.srtCharacters:
            sortOrder += 1
            xmlCrt = ET.SubElement(xmlCharacters, 'CHARACTER')
            ET.SubElement(xmlCrt, 'ID').text = crId
            build_character_subtree(xmlCrt, self.novel.characters[crId], sortOrder)


        if xmlProjectnotes is not None:
            for xmlPnt in xmlProjectnotes.findall('PROJECTNOTE'):
                xmlProjectnotes.remove(xmlPnt)
            if not self.novel.srtPrjNotes:
                root.remove(xmlProjectnotes)
        elif self.novel.srtPrjNotes:
            xmlProjectnotes = ET.SubElement(root, 'PROJECTNOTES')
        if self.novel.srtPrjNotes:
            sortOrder = 0
            for pnId in self.novel.srtPrjNotes:
                sortOrder += 1
                xmlPnt = ET.SubElement(xmlProjectnotes, 'PROJECTNOTE')
                ET.SubElement(xmlPnt, 'ID').text = pnId
                build_prjNote_subtree(xmlPnt, self.novel.projectNotes[pnId], sortOrder)

        if self.novel.languages or self.novel.languageCode or self.novel.countryCode:
            self.novel.check_locale()
            projectvars = root.find('PROJECTVARS')
            if projectvars is None:
                projectvars = ET.SubElement(root, 'PROJECTVARS')
            prjVars = []
            languages = self.novel.languages.copy()
            hasLanguageCode = False
            hasCountryCode = False
            for projectvar in projectvars.findall('PROJECTVAR'):
                prjVars.append(projectvar.find('ID').text)
                title = projectvar.find('Title').text

                if title.startswith('lang='):
                    try:
                        __, langCode = title.split('=')
                        languages.remove(langCode)
                    except:
                        pass

                elif title == 'Language':
                    projectvar.find('Desc').text = self.novel.languageCode
                    hasLanguageCode = True

                elif title == 'Country':
                    projectvar.find('Desc').text = self.novel.countryCode
                    hasCountryCode = True

            if not hasLanguageCode:
                add_projectvariable('Language',
                                    self.novel.languageCode,
                                    '0')

            if not hasCountryCode:
                add_projectvariable('Country',
                                    self.novel.countryCode,
                                    '0')

            for langCode in languages:
                add_projectvariable(f'lang={langCode}',
                                    f'<HTM <SPAN LANG="{langCode}"> /HTM>',
                                    '0')
                add_projectvariable(f'/lang={langCode}',
                                    f'<HTM </SPAN> /HTM>',
                                    '0')


        for xmlScene in xmlScenes.findall('SCENE'):
            scId = xmlScene.find('ID').text
            xmlNewScenes[scId] = xmlScene
            xmlScenes.remove(xmlScene)

        for scId in self.novel.scenes:
            if not scId in xmlNewScenes:
                xmlNewScenes[scId] = ET.Element('SCENE')
                ET.SubElement(xmlNewScenes[scId], 'ID').text = scId
            build_scene_subtree(xmlNewScenes[scId], self.novel.scenes[scId])
            xmlScenes.append(xmlNewScenes[scId])


        for xmlChapter in xmlChapters.findall('CHAPTER'):
            chId = xmlChapter.find('ID').text
            xmlNewChapters[chId] = xmlChapter
            xmlChapters.remove(xmlChapter)

        sortOrder = 0
        for chId in self.novel.srtChapters:
            sortOrder += 1
            if not chId in xmlNewChapters:
                xmlNewChapters[chId] = ET.Element('CHAPTER')
                ET.SubElement(xmlNewChapters[chId], 'ID').text = chId
            build_chapter_subtree(xmlNewChapters[chId], self.novel.chapters[chId], sortOrder)
            xmlChapters.append(xmlNewChapters[chId])

        for xmlScene in root.find('SCENES'):
            scId = xmlScene.find('ID').text
            if self.novel.scenes[scId].sceneContent is not None:
                xmlScene.find('SceneContent').text = self.novel.scenes[scId].sceneContent
                xmlScene.find('WordCount').text = str(self.novel.scenes[scId].wordCount)
                xmlScene.find('LetterCount').text = str(self.novel.scenes[scId].letterCount)
            try:
                xmlScene.remove(xmlScene.find('RTFFile'))
            except:
                pass

        indent(root)
        self.tree = ET.ElementTree(root)

    def _postprocess_xml_file(self, filePath):
        '''Postprocess an xml file created by ElementTree.
        
        Positional argument:
            filePath: str -- path to xml file.
        
        Read the xml file, put a header on top, insert the missing CDATA tags,
        and replace xml entities by plain text (unescape). Overwrite the .yw7 xml file.
        Raise the "Error" exception in case of error. 
        
        Note: The path is given as an argument rather than using self.filePath. 
        So this routine can be used for yWriter-generated xml files other than .yw7 as well. 
        '''
        with open(filePath, 'r', encoding='utf-8') as f:
            text = f.read()
        lines = text.split('\n')
        newlines = ['<?xml version="1.0" encoding="utf-8"?>']
        for line in lines:
            for tag in self._CDATA_TAGS:
                line = re.sub(f'\<{tag}\>', f'<{tag}><![CDATA[', line)
                line = re.sub(f'\<\/{tag}\>', f']]></{tag}>', line)
            newlines.append(line)
        text = '\n'.join(newlines)
        text = text.replace('[CDATA[ \n', '[CDATA[')
        text = text.replace('\n]]', ']]')
        if not self.novel.chapters:
            text = text.replace('<CHAPTERS />', '<CHAPTERS></CHAPTERS>')
        text = unescape(text)
        try:
            with open(filePath, 'w', encoding='utf-8') as f:
                f.write(text)
        except:
            raise Error(f'{_("Cannot write file")}: "{norm_path(filePath)}".')

    def _strip_spaces(self, lines):
        stripped = []
        for line in lines:
            stripped.append(line.strip())
        return stripped

    def _write_element_tree(self, ywProject):
        backedUp = False
        if os.path.isfile(ywProject.filePath):
            try:
                os.replace(ywProject.filePath, f'{ywProject.filePath}.bak')
            except:
                raise Error(f'{_("Cannot overwrite file")}: "{norm_path(ywProject.filePath)}".')
            else:
                backedUp = True
        try:
            ywProject.tree.write(ywProject.filePath, xml_declaration=False, encoding='utf-8')
        except:
            if backedUp:
                os.replace(f'{ywProject.filePath}.bak', ywProject.filePath)
            raise Error(f'{_("Cannot write file")}: "{norm_path(ywProject.filePath)}".')


LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
CURRENT_LANGUAGE = locale.getlocale()[0][:2]
try:
    t = gettext.translation('novelyst_aeon2', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

APPLICATION = 'Aeon Timeline 2'
PLUGIN = f'{APPLICATION} plugin v3.4.1'
INI_FILENAME = 'aeon2yw.ini'
INI_FILEPATH = '.pywriter/aeon2yw/config'


class Plugin():
    """Plugin class for synchronization with Aeon Timeline 2.
    
    Public methods:
        disable_menu() -- disable menu entries when no project is open.
        enable_menu() -- enable menu entries when a project is open.
        
    """
    VERSION = '3.4.1'
    NOVELYST_API = '4.0'
    DESCRIPTION = 'Synchronize with Aeon Timeline 2'
    URL = 'https://peter88213.github.io/novelyst_aeon2'
    _HELP_URL = 'https://peter88213.github.io/novelyst_aeon2/usage'

    SETTINGS = dict(
        default_date_time='2023-01-01 00:00:00',
        narrative_arc='Narrative',
        property_description='Description',
        property_notes='Notes',
        role_location='Location',
        role_item='Item',
        role_character='Participant',
        type_character='Character',
        type_location='Location',
        type_item='Item',
        color_scene='Red',
        color_event='Yellow',
        color_point='Blue',
    )
    OPTIONS = dict(
        scenes_only=True,
        add_moonphase=False,
    )

    def install(self, ui):
        """Add a submenu to the main menu.
        
        Positional arguments:
            ui -- reference to the NovelystTk instance of the application.
        """
        self._ui = ui

        self._pluginMenu = tk.Menu(self._ui.toolsMenu, tearoff=0)
        self._ui.toolsMenu.add_cascade(label=APPLICATION, menu=self._pluginMenu)
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')
        self._pluginMenu.add_command(label=_('Information'), command=self._info)
        self._pluginMenu.add_separator()
        self._pluginMenu.add_command(label=_('Update the timeline'), command=self._export_from_yw)
        self._pluginMenu.add_command(label=_('Update the project'), command=self._import_to_yw)
        self._pluginMenu.add_separator()
        self._pluginMenu.add_command(label=_('Add or update moon phase data'), command=self._add_moonphase)
        self._pluginMenu.add_separator()
        self._pluginMenu.add_command(label=_('Edit the timeline'), command=self._launch_application)

        self._ui.helpMenu.add_command(label=_('Aeon 2 plugin Online help'), command=lambda: webbrowser.open(self._HELP_URL))

    def _get_config(self, sourcePath):
        """ Read persistent configuration data for Aeon 2 conversion.
        
        First, look for a global configuration file in the aeon2yw installation directory,
        then look for a local configuration file in the project directory.
        """
        sourceDir = os.path.dirname(sourcePath)
        if not sourceDir:
            sourceDir = '.'
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            pluginCnfDir = f'{homeDir}/{INI_FILEPATH}'
        except:
            pluginCnfDir = '.'
        iniFiles = [f'{pluginCnfDir}/{INI_FILENAME}', f'{sourceDir}/{INI_FILENAME}']
        configuration = Configuration(self.SETTINGS, self.OPTIONS)
        for iniFile in iniFiles:
            configuration.read(iniFile)
        kwargs = {}
        kwargs.update(configuration.settings)
        kwargs.update(configuration.options)
        return kwargs

    def _edit_settings(self):
        return

    def disable_menu(self):
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')

    def enable_menu(self):
        self._ui.toolsMenu.entryconfig(APPLICATION, state='normal')

    def _launch_application(self):
        if self._ui.prjFile:
            timelinePath = f'{os.path.splitext(self._ui.prjFile.filePath)[0]}{JsonTimeline2.EXTENSION}'
            if os.path.isfile(timelinePath):
                if self._ui.lock():
                    open_document(timelinePath)
            else:
                self._ui.set_info_how(_('!No {} file available for this project.').format(APPLICATION))

    def _add_moonphase(self):
        """Add/update moon phase data.
        
        Add the moon phase to the event properties.
        If the moon phase event property already exists, just update.
        """
        if self._ui.prjFile:
            timelinePath = f'{os.path.splitext(self._ui.prjFile.filePath)[0]}{JsonTimeline2.EXTENSION}'
            if os.path.isfile(timelinePath):
                sourceDir = os.path.dirname(timelinePath)
                if not sourceDir:
                    sourceDir = '.'
                try:
                    homeDir = str(Path.home()).replace('\\', '/')
                    pluginCnfDir = f'{homeDir}/{INI_FILEPATH}'
                except:
                    pluginCnfDir = '.'
                iniFiles = [f'{pluginCnfDir}/{INI_FILENAME}', f'{sourceDir}/{INI_FILENAME}']
                configuration = Configuration(self.SETTINGS, self.OPTIONS)
                for iniFile in iniFiles:
                    configuration.read(iniFile)
                kwargs = {}
                kwargs.update(configuration.settings)
                kwargs.update(configuration.options)
                kwargs['add_moonphase'] = True
                timeline = JsonTimeline2(timelinePath, **kwargs)
                try:
                    timeline.read()
                    timeline.write()
                    message = f'{_("File written")}: "{norm_path(timeline.filePath)}".'
                except Error as ex:
                    message = f'!{str(ex)}'
                self._ui.set_info_how(message)

    def _info(self):
        if self._ui.prjFile:
            timelinePath = f'{os.path.splitext(self._ui.prjFile.filePath)[0]}{JsonTimeline2.EXTENSION}'
            if os.path.isfile(timelinePath):
                try:
                    timestamp = os.path.getmtime(timelinePath)
                    if timestamp > self._ui.prjFile.timestamp:
                        cmp = _('newer')
                    else:
                        cmp = _('older')
                    fileDate = datetime.fromtimestamp(timestamp).replace(microsecond=0).isoformat(sep=' ')
                    message = _('{0} file is {1} than the novelyst project.\n (last saved on {2})').format(APPLICATION, cmp, fileDate)
                except:
                    message = _('Cannot determine file date.')
            else:
                message = _('No {} file available for this project.').format(APPLICATION)
            messagebox.showinfo(PLUGIN, message)

    def _export_from_yw(self):
        """Update the timeline from novelyst.
        
        Note:
        This works by merging the timeline with the open project as a source object.
        The JsonTimeline2 target object's merge method reads from the disk.
        """
        if self._ui.prjFile:
            timelinePath = f'{os.path.splitext(self._ui.prjFile.filePath)[0]}{JsonTimeline2.EXTENSION}'
            if not os.path.isfile(timelinePath):
                self._ui.set_info_how(_('!No {} file available for this project.').format(APPLICATION))
                return

            if self._ui.ask_yes_no(_('Save the project and update the timeline?')):
                self._ui.save_project()
                kwargs = self._get_config(timelinePath)
                source = Yw7File(self._ui.prjFile.filePath, **kwargs)
                source.novel = Novel()
                target = JsonTimeline2(timelinePath, **kwargs)
                try:
                    source.read()
                    target.novel = source.novel
                    target.write()
                    message = f'{_("File written")}: "{norm_path(target.filePath)}".'
                except Error as ex:
                    message = f'!{str(ex)}'
                self._ui.set_info_how(message)

    def _import_to_yw(self):
        """Update the current project from the timeline.
        
        Note:
        The Yw7WorkFile object of the open project cannot be used as target object.
        This is because the JsonTimeline2 source object's IDs do not match, so 
        the scenes and other elements are identified by their titles when merging.
        This is done by the special Yw7Target object. Its merge method reads from the disk. 
        Re-reading the project afterwards is the safest way to get a display update.
        """
        if self._ui.prjFile:
            timelinePath = f'{os.path.splitext(self._ui.prjFile.filePath)[0]}{JsonTimeline2.EXTENSION}'
            if not os.path.isfile(timelinePath):
                self._ui.set_info_how(_('!No {} file available for this project.').format(APPLICATION))
                return

            if self._ui.ask_yes_no(_('Save the project and update it?')):
                self._ui.save_project()
                kwargs = self._get_config(timelinePath)
                source = JsonTimeline2(timelinePath, **kwargs)
                target = Yw7File(self._ui.prjFile.filePath, **kwargs)
                try:
                    target.novel = Novel()
                    target.read()
                    source.novel = target.novel
                    source.read()
                    target.novel = source.novel
                    target.write()
                    message = f'{_("File written")}: "{norm_path(target.filePath)}".'
                except Error as ex:
                    message = f'!{str(ex)}'

                self._ui.reloading = True
                self._ui.open_project(self._ui.prjFile.filePath)
                self._ui.set_info_how(message)
